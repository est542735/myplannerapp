package com.example.myplanner;
public class Event {
    public int id;
    public String title;
    public String date;
    public String time;
    public String color;

    public Event(int id, String title, String date, String time, String color) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.color = color;
    }
}
