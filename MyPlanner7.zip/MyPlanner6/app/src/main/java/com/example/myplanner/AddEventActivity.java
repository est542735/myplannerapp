package com.example.myplanner;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;

public class AddEventActivity extends AppCompatActivity {
    EditText titleInput;
    Button dateButton, timeButton, saveButton;
    Spinner colorSpinner;
    DatabaseHelper dbHelper;

    String selectedDate = "", selectedTime = "", selectedColor = "#FF0000"; // Default color

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        titleInput = findViewById(R.id.titleInput);
        dateButton = findViewById(R.id.dateButton);
        timeButton = findViewById(R.id.timeButton);
        colorSpinner = findViewById(R.id.colorSpinner);
        saveButton = findViewById(R.id.saveButton);
        dbHelper = new DatabaseHelper(this);

        // Color names and corresponding hex values
        String[] colorNames = {"Red", "Green", "Blue", "Orange"};
        String[] colorHexValues = {"#FF0000", "#00FF00", "#0000FF", "#FFA500"};

        // Custom ArrayAdapter to show color name and preview
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item, R.id.colorName, colorNames) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView colorName = view.findViewById(R.id.colorName);
                View colorView = view.findViewById(R.id.colorView);
                colorName.setText(colorNames[position]);
                colorView.setBackgroundColor(Color.parseColor(colorHexValues[position])); // Set background color
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView colorName = view.findViewById(R.id.colorName);
                View colorView = view.findViewById(R.id.colorView);
                colorName.setText(colorNames[position]);
                colorView.setBackgroundColor(Color.parseColor(colorHexValues[position])); // Set background color
                return view;
            }
        };

        colorSpinner.setAdapter(adapter);

        dateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
                selectedDate = year + "-" + (month + 1) + "-" + day;
                dateButton.setText(selectedDate);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            picker.show();
        });

        timeButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog picker = new TimePickerDialog(this, (view, hour, minute) -> {
                selectedTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
                timeButton.setText(selectedTime);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
            picker.show();
        });

        saveButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString();
            int selectedPosition = colorSpinner.getSelectedItemPosition();
            selectedColor = colorHexValues[selectedPosition]; // Get the corresponding hex value for the selected color name

            if (!title.isEmpty() && !selectedDate.isEmpty()) {
                dbHelper.insertEvent(title, selectedDate, selectedTime, selectedColor);
                Toast.makeText(this, "Event Saved!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
