package com.example.myplanner;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.widget.CalendarView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    CalendarView calendarView;
    RecyclerView recyclerView;
    DatabaseHelper dbHelper;
    EventsAdapter adapter;
    List<Event> eventList = new ArrayList<>();
    String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        calendarView = findViewById(R.id.calendarView);
        recyclerView = findViewById(R.id.recyclerView);
        dbHelper = new DatabaseHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
            loadEvents();
        });

        findViewById(R.id.addButton).setOnClickListener(v -> {
            startActivity(new Intent(this, AddEventActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!selectedDate.isEmpty()) loadEvents();
    }

    private void loadEvents() {
        eventList.clear();
        Cursor c = dbHelper.getEventsByDate(selectedDate);
        while (c.moveToNext()) {
            int id = c.getInt(0);
            String title = c.getString(1);
            String date = c.getString(2);
            String time = c.getString(3);
            String color = c.getString(4);
            eventList.add(new Event(id, title, date, time, color));
        }

        adapter = new EventsAdapter(this, eventList, new EventsAdapter.OnEventClickListener() {
            @Override
            public void onEdit(Event e) {
                // TODO: לערוך אירוע - ניתן להעביר את הנתונים ל-AddEventActivity
            }

            @Override
            public void onDelete(Event e) {
                dbHelper.deleteEvent(e.id);
                loadEvents();
            }
        });
        recyclerView.setAdapter(adapter);
    }
}
