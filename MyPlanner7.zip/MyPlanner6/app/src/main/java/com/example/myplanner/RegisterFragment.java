package com.example.myplanner;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

import java.io.ByteArrayOutputStream;

public class RegisterFragment extends Fragment {

    private EditText etUsername, etPhone, etPassword;
    private Button btnRegister;
    private ImageButton btnReturn, btnPasswordVisibility;
    private boolean isPasswordVisible = false;

    public RegisterFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_register, container, false);

        etUsername = rootView.findViewById(R.id.etRegisterUsername);
        etPhone = rootView.findViewById(R.id.etRegisterPhone);
        etPassword = rootView.findViewById(R.id.etRegisterPassword);
        btnRegister = rootView.findViewById(R.id.btnRegister);
        btnReturn = rootView.findViewById(R.id.btnReturn);
        btnPasswordVisibility = rootView.findViewById(R.id.btnPasswordVisibility);

        btnPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    btnPasswordVisibility.setImageResource(R.drawable.eye);
                } else {
                    etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    btnPasswordVisibility.setImageResource(R.drawable.eye);
                }
                etPassword.setSelection(etPassword.getText().length());
                isPasswordVisible = !isPasswordVisible;
            }
        });

        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String phone = etPhone.getText().toString().trim();
                String password = etPassword.getText().toString();

                // בדיקות תקינות
                if (username.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getActivity(), "נא למלא את כל השדות", Toast.LENGTH_SHORT).show();
                } else if (username.length() < 3) {
                    Toast.makeText(getActivity(), "שם המשתמש חייב להכיל לפחות 3 תווים", Toast.LENGTH_SHORT).show();
                } else if (!phone.matches("\\d{10}")) {
                    Toast.makeText(getActivity(), "מספר טלפון חייב להכיל בדיוק 10 ספרות", Toast.LENGTH_SHORT).show();
                } else if (password.length() < 6) {
                    Toast.makeText(getActivity(), "הסיסמה חייבת להכיל לפחות 6 תווים", Toast.LENGTH_SHORT).show();
                } else if (dbHelper.isPhoneExists(phone)) {
                    Toast.makeText(getActivity(), "מספר הטלפון כבר קיים במערכת", Toast.LENGTH_SHORT).show();
                } else {
                    // תמונת פרופיל ברירת מחדל
                    Bitmap profileBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.profile);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    profileBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byte[] profilePicBytes = byteArrayOutputStream.toByteArray();

                    boolean isInserted = dbHelper.insertUser(username, phone, password, profilePicBytes);
                    if (isInserted) {
                        Toast.makeText(getActivity(), "ההרשמה הצליחה", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getActivity(), HomeActivity.class);
                        startActivity(intent);
                        getActivity().finish();
                    } else {
                        Toast.makeText(getActivity(), "שגיאה בהרשמה, נסה שוב", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });

        return rootView;
    }
}
