package com.example.myplannermarch;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        // אם לא קיים פרגמנט כבר (למניעת הצגה חוזרת)
        if (savedInstanceState == null) {
            // החלף את התצוגה עם ה-HomeFragment
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())  // מזהה של ה-FrameLayout
                    .commit();
        }
    }
}
