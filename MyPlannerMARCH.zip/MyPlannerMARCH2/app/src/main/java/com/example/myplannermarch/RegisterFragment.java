package com.example.myplannermarch;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class RegisterFragment extends Fragment {

    private EditText etUsername, etPhone, etPassword;
    private ImageButton btnPasswordVisibility,  btnReturn;
    private Button  btnRegister;
    private DatabaseHelper dbHelper;

    public RegisterFragment() {
        // קונסטרקטור ריק נדרש
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // אתחול המשתנים
        etUsername = view.findViewById(R.id.etRegisterUsername);
        etPhone = view.findViewById(R.id.etRegisterPhone);
        etPassword = view.findViewById(R.id.etRegisterPassword);
        btnPasswordVisibility = view.findViewById(R.id.btnPasswordVisibility);
        btnRegister = view.findViewById(R.id.btnRegister);
        btnReturn = view.findViewById(R.id.btnReturn);
        dbHelper = new DatabaseHelper(getActivity());

        // כפתור הצגת/הסתרת סיסמה
        btnPasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etPassword.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    btnPasswordVisibility.setImageResource(R.drawable.eye); // תמונת עין סגורה
                } else {
                    etPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    btnPasswordVisibility.setImageResource(R.drawable.eye); // תמונת עין פתוחה
                }
                etPassword.setSelection(etPassword.getText().length()); // שמירת מיקום הסמן
            }
        });

        // כפתור הרשמה
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        // כפתור חזרה למסך ההתחברות
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), LoginActivity.class));
                getActivity().finish();
            }
        });

        return view;
    }

    // פונקציה לרישום המשתמש
    private void registerUser() {
        String username = etUsername.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // בדיקה שהשדות לא ריקים
        if (username.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "יש למלא את כל השדות!", Toast.LENGTH_SHORT).show();
            return;
        }

        // בדיקה אם מספר הטלפון חוקי (9-10 ספרות)
        if (!phone.matches("\\d{9,10}")) {
            Toast.makeText(getActivity(), "מספר הטלפון חייב להיות 9 או 10 ספרות!", Toast.LENGTH_SHORT).show();
            return;
        }

        // בדיקה אם הסיסמה באורך של לפחות 6 תווים
        if (password.length() < 6) {
            Toast.makeText(getActivity(), "הסיסמה חייבת להכיל לפחות 6 תווים!", Toast.LENGTH_SHORT).show();
            return;
        }

        // ניסיון לרשום את המשתמש למסד הנתונים
        boolean success = dbHelper.registerUser(username, phone, password, getActivity());
        if (success) {
            Toast.makeText(getActivity(), "נרשמת בהצלחה!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getActivity(), HomeActivity.class));
            getActivity().finish();
        } else {
            Toast.makeText(getActivity(), "שם המשתמש כבר קיים!", Toast.LENGTH_SHORT).show();
        }
    }
}
