package com.example.myplannermarch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin, btnRegister;
    private ImageButton btnTogglePasswordVisibility;
    private boolean isPasswordVisible = false;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // מקשר את האובייקטים ל-XML
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnTogglePasswordVisibility = findViewById(R.id.btnPasswordVisibility);

        dbHelper = new DatabaseHelper(this);

        // הוספת פעולה לכפתור התחברות
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                if(username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "נא להזין שם משתמש וסיסמה", Toast.LENGTH_SHORT).show();
                } else {
                    // בדיקת כניסה בעזרת פונקציה ב-DatabaseHelper
                    if (dbHelper.validateLogin(username, password)) {
                        // שמירת שם המשתמש ב-SharedPreferences
                        SharedPreferences sharedPreferences = getSharedPreferences("MyApp", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username", username); // שמירת שם המשתמש
                        editor.apply();

                        // אם שם המשתמש והסיסמה נכונים, נעבור ל־HomeActivity
                        Toast.makeText(LoginActivity.this, "התחברות הצליחה", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish(); // סוגר את ה־LoginActivity כדי למנוע חזרה אחורה
                    } else {
                        // אם שם המשתמש או הסיסמה לא נכונים
                        Toast.makeText(LoginActivity.this, "שם משתמש או סיסמה לא נכונים", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // הוספת פעולה לכפתור הרשמה
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction()
                        .replace(android.R.id.content, new RegisterFragment())
                        .addToBackStack(null)
                        .commit();
            }
        });

        // הוספת פעולה לכפתור עין להסתיר/להציג סיסמה
        btnTogglePasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    etPassword.setInputType(129); // 129 זה מצב של textPassword
                    btnTogglePasswordVisibility.setImageResource(R.drawable.eye); // החלפת אייקון העין
                } else {
                    etPassword.setInputType(144); // 144 זה מצב של textVisiblePassword
                    btnTogglePasswordVisibility.setImageResource(R.drawable.eye); // החלפת אייקון העין
                }
                isPasswordVisible = !isPasswordVisible;
                etPassword.setSelection(etPassword.length()); // מיקום הקורסור בסוף הסיסמה
            }
        });
    }
}
