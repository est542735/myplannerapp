package com.example.myplannermarch;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin, btnRegister;
    private ImageButton btnTogglePasswordVisibility; // כפתור עין
    private boolean isPasswordVisible = false; // משתנה לצורך שליטה אם הסיסמה גלויה או לא

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // מחבר את ה-XML של הלוגין

        // מקשר את האובייקטים ל-XML
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnTogglePasswordVisibility = findViewById(R.id.btnPasswordVisibility); // מקשר לכפתור עין

        dbHelper = new DatabaseHelper(this); // יצירת אובייקט של DatabaseHelper

        // הוספת פעולה לכפתור התחברות
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                if(username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "נא להזין שם משתמש וסיסמה", Toast.LENGTH_SHORT).show();
                } else {
                    // בדיקת כניסה בעזרת פונקציה ב-DatabaseHelper
                    if (dbHelper.validateLogin(username, password)) {
                        // אם שם המשתמש והסיסמה נכונים, נעבור ל־HomeActivity
                        Toast.makeText(LoginActivity.this, "התחברות הצליחה", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish(); // סוגר את ה־LoginActivity כדי למנוע חזרה אחורה
                    } else {
                        // אם שם המשתמש או הסיסמה לא נכונים
                        Toast.makeText(LoginActivity.this, "שם משתמש או סיסמה לא נכונים", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // הוספת פעולה לכפתור הרשמה
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // הוספת פרגמנט הרשמה כאן (למשל, מעבר ל-RegisterFragment)
                getSupportFragmentManager().beginTransaction()
                        .replace(android.R.id.content, new RegisterFragment()) // הוספת פרגמנט לרשום
                        .addToBackStack(null) // אפשרות לחזור אחורה
                        .commit();
            }
        });

        // הוספת פעולה לכפתור עין להסתיר/להציג סיסמה
        btnTogglePasswordVisibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    // אם הסיסמה גלויה, להחביא אותה
                    etPassword.setInputType(129); // 129 זה מצב של textPassword
                    btnTogglePasswordVisibility.setImageResource(R.drawable.eye); // החלפת אייקון העין
                } else {
                    // אם הסיסמה לא גלויה, להראות אותה
                    etPassword.setInputType(144); // 144 זה מצב של textVisiblePassword
                    btnTogglePasswordVisibility.setImageResource(R.drawable.eye); // החלפת אייקון העין
                }
                isPasswordVisible = !isPasswordVisible; // שינוי סטטוס (האם הסיסמה גלויה או לא)
                etPassword.setSelection(etPassword.length()); // מיקום הקורסור בסוף הסיסמה
            }
        });
    }
}
