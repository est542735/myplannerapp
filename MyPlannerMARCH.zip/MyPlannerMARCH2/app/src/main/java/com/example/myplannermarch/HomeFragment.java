package com.example.myplannermarch;

import android.content.Intent; // הוספת import ל-Intent
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.CalendarView;

import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    private ListView menuListView;
    private ImageButton btnToggleMenu;
    private CalendarView calendarView; // הוספת משתנה ל-CalendarView

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        // קישור ל-ListView, כפתור ולוח שנה
        menuListView = rootView.findViewById(R.id.menuListView);
        btnToggleMenu = rootView.findViewById(R.id.btnToggleMenu);
        calendarView = rootView.findViewById(R.id.calendarView); // קישור ל-CalendarView

        // יצירת המערך של פריטי התפריט עם "בית" ראשון
        String[] menuItems = {"בית", "האירועים שלי", "התנתקות"};

        // יצירת ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, menuItems);
        menuListView.setAdapter(adapter);

        // מאזין ללחיצה על פריט בתפריט
        menuListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        // בית - חזרה למסך הבית
                        goToHome();
                        break;
                    case 1:
                        // האירועים שלי - הצגת התוכן של האירועים
                        openEventsFragment();
                        break;
                    case 2:
                        // התנתקות - חזרה למסך כניסה (LoginActivity)
                        goToLogin();
                        break;
                    default:
                        break;
                }
            }
        });

        // הוספת מאזין לכפתור שיפתח ויסגור את ה-ListView
        btnToggleMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (menuListView.getVisibility() == View.GONE) {
                    menuListView.setVisibility(View.VISIBLE);
                } else {
                    menuListView.setVisibility(View.GONE);
                }
            }
        });

        // הוספת מאזין לאירוע בחירת תאריך בלוח שנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // יצירת תאריך נבחר בפורמט YYYY-MM-DD
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth; // חודש מתואם
            // פתיחת פרגמנט להוספת אירוע עם התאריך שנבחר
            openAddEventFragment(selectedDate);
        });

        return rootView;
    }

    private void openAddEventFragment(String selectedDate) {
        // יצירת פרגמנט של הוספת אירוע עם התאריך שנבחר
        AddEventFragment addEventFragment = AddEventFragment.newInstance(selectedDate);

        // החלפת הפרגמנט הנוכחי ב-HomeFragment לפרגמנט של הוספת אירוע
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, addEventFragment) // מזהה ה-FrameLayout
                .addToBackStack(null) // הוספת פעולה לסטאק של פעולות להחזרה אחורה
                .commit();
    }

    private void openEventsFragment() {
        // יצירת פרגמנט של האירועים
        EventsFragment eventsFragment = new EventsFragment();

        // החלפת הפרגמנט הנוכחי ב-HomeFragment לפרגמנט של האירועים
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, eventsFragment) // מזהה ה-FrameLayout
                .addToBackStack(null) // הוספת פעולה לסטאק של פעולות להחזרה אחורה
                .commit();
    }

    private void goToHome() {
        // אם אנחנו כבר בבית, אין צורך לעבור
        if (!(getActivity() instanceof MainActivity)) {
            // העברת למסך הבית אם אנחנו לא כבר שם
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())
                    .addToBackStack(null)
                    .commit();
        }
    }

    private void goToLogin() {
        // יצירת Intent למעבר למסך הלוגין
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        startActivity(intent); // התחלת פעילות הלוגין
        getActivity().finish(); // סגירת הפעילות הנוכחית
    }
}
