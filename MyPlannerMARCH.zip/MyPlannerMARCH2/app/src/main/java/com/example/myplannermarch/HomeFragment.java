package com.example.myplannermarch;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.io.IOException;

public class HomeFragment extends Fragment {

    private ListView menuListView;
    private ImageButton btnToggleMenu;
    private CalendarView calendarView;
    private TextView txtWelcomeMessage;
    private ImageView imgProfilePic;  // הוספתי את ה-ImageView

    private String username; // שם המשתמש שלך
    private static final int REQUEST_CAMERA = 100;
    private static final int REQUEST_GALLERY = 101;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        // קישור ל-ListView ולכפתור
        menuListView = rootView.findViewById(R.id.menuListView);
        btnToggleMenu = rootView.findViewById(R.id.btnToggleMenu);
        calendarView = rootView.findViewById(R.id.calendarView);
        txtWelcomeMessage = rootView.findViewById(R.id.txtWelcomeMessage);
        imgProfilePic = rootView.findViewById(R.id.imgProfilePic);  // קישור לתמונת פרופיל

        // קריאה מ-SharedPreferences כדי לקבל את שם המשתמש
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MyApp", getActivity().MODE_PRIVATE);
        username = sharedPreferences.getString("username", "שם משתמש");

        // הצגת שם המשתמש בהודעת ברוך הבא
        String welcomeText = "WELCOME BACK, " + username;
        txtWelcomeMessage.setText(welcomeText);

        // יצירת המערך של פריטי התפריט עם "בית" ראשון
        String[] menuItems = {"בית", "האירועים שלי", "התנתקות"};

        // יצירת ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, menuItems);
        menuListView.setAdapter(adapter);

        // מאזין ללחיצה על פריט בתפריט
        menuListView.setOnItemClickListener((parent, view, position, id) -> {
            switch (position) {
                case 0:
                    goToHome();
                    break;
                case 1:
                    openEventsFragment();
                    break;
                case 2:
                    getActivity().finish();
                    break;
                default:
                    break;
            }
        });

        // הוספת מאזין לכפתור שיפתח ויסגור את ה-ListView
        btnToggleMenu.setOnClickListener(v -> {
            if (menuListView.getVisibility() == View.GONE) {
                menuListView.setVisibility(View.VISIBLE);
            } else {
                menuListView.setVisibility(View.GONE);
            }
        });

        // הוספת מאזין ללחיצה על תאריך ב-CalendarView
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
            openAddEventFragment(selectedDate);
        });

        // מאזין ללחיצה על תמונת פרופיל
        imgProfilePic.setOnClickListener(v -> showImageSourceDialog());

        // הצגת התוכן הראשוני של הבית
        return rootView;
    }

    // הצגת דיאלוג לבחירת מקור התמונה (מצלמה או גלריה)
    private void showImageSourceDialog() {
        // יצירת Intent להציג את הדיאלוג
        String[] options = {"מצלמה", "גלריה"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("בחר מקור תמונה")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openCamera();
                    } else if (which == 1) {
                        openGallery();
                    }
                })
                .show();
    }

    // פתיחת המצלמה
    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, REQUEST_CAMERA);
    }

    // פתיחת הגלריה
    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, REQUEST_GALLERY);
    }

    // טיפול בתוצאה של המצלמה או הגלריה
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                // תמונה נלקחה מהמצלמה
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                imgProfilePic.setImageBitmap(bitmap);
            } else if (requestCode == REQUEST_GALLERY) {
                // תמונה נבחרה מהגלריה
                Uri imageUri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                    imgProfilePic.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "שגיאה בטעינת התמונה", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void openAddEventFragment(String selectedDate) {
        AddEventFragment addEventFragment = AddEventFragment.newInstance(selectedDate);
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, addEventFragment)
                .addToBackStack(null)
                .commit();
    }

    private void openEventsFragment() {
        EventsFragment eventsFragment = new EventsFragment();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, eventsFragment)
                .addToBackStack(null)
                .commit();
    }

    private void goToHome() {
        if (!(getActivity() instanceof MainActivity)) {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())
                    .addToBackStack(null)
                    .commit();
        }
    }
}
