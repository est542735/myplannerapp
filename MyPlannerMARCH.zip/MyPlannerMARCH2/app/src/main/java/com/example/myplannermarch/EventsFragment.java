package com.example.myplannermarch;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

public class EventsFragment extends Fragment {

    private DrawerLayout drawerLayout;
    private View menuContainer;
    private ListView menuListView;
    private ImageButton btnToggleMenu;

    public EventsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_events, container, false);

        // קישור לרכיבים ב-XML
        drawerLayout = rootView.findViewById(R.id.drawerLayout);
        menuContainer = rootView.findViewById(R.id.menuContainer); // התפריט כולו
        menuListView = rootView.findViewById(R.id.menuListView);
        btnToggleMenu = rootView.findViewById(R.id.btnToggleMenu);

        // יצירת המערך של פריטי התפריט
        String[] menuItems = {"דף הבית", "האירועים שלי", "התנתקות"};

        // יצירת ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, menuItems);
        menuListView.setAdapter(adapter);

        // הוספת מאזין לכפתור שיפתח ויסגור את התפריט
        btnToggleMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(menuContainer)) {
                    drawerLayout.closeDrawer(menuContainer);
                } else {
                    drawerLayout.openDrawer(menuContainer);
                }
            }
        });

        // מאזין ללחיצה על פריט בתפריט
        menuListView.setOnItemClickListener((parent, view, position, id) -> {
            switch (position) {
                case 0:
                    // חזרה לדף הבית - פתח את HomeFragment
                    openHomeFragment();
                    break;
                case 1:
                    // האירועים שלי - הצגת רשימת האירועים (כרגע ריק)
                    break;
                case 2:
                    // התנתקות - חזרה ללוגין
                    logout();
                    break;
                default:
                    break;
            }
            drawerLayout.closeDrawer(menuContainer); // סגירת התפריט אחרי לחיצה
        });

        return rootView;
    }

    private void openHomeFragment() {
        // יצירת פרגמנט של דף הבית
        HomeFragment homeFragment = new HomeFragment();

        // החלפת פרגמנט של האירועים בפרגמנט של הבית
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, homeFragment) // מזהה ה-FrameLayout שבו יתחלף הפרגמנט
                .addToBackStack(null) // הוספת הפעולה לסטאק כך שניתן לחזור אחורה
                .commit();
    }

    private void logout() {
        // יצירת Intent ללוגין
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // מנקה את הסטאק ומעביר רק למסך הלוגין
        startActivity(intent);
        getActivity().finish(); // סוגר את הפעילות הנוכחית (הפנייה לא תוביל חזרה לאפליקציה)
    }
}
