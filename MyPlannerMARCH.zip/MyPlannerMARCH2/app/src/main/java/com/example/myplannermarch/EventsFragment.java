package com.example.myplannermarch;

import static android.app.PendingIntent.getActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class EventsFragment extends Fragment {

    private ListView lvEvents;
    private String[] events = {"אירוע 1", "אירוע 2", "אירוע 3"};

    public EventsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_events, container, false);

        // קישור ל-ListView
        lvEvents = view.findViewById(R.id.lvEvents);

        // יצירת ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, events);
        lvEvents.setAdapter(adapter);

        // מאזין ללחיצה על פריט ברשימה
        lvEvents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // פעולה כשנלחץ על פריט (למשל הצגת פרטי האירוע)
                String event = events[position];
                Toast.makeText(getActivity(), "נבחר האירוע: " + event, Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
