package com.example.myplannermarch;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class EventsFragment extends Fragment {

    private DrawerLayout drawerLayout;
    private View menuContainer;
    private ListView menuListView;
    private ImageButton btnToggleMenu;
    private ListView lvEvents;  // ListView של האירועים
    private DatabaseHelper dbHelper;  // ה-Helper למסד הנתונים

    public EventsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_events, container, false);

        // קישור לרכיבים ב-XML
        drawerLayout = rootView.findViewById(R.id.drawerLayout);
        menuContainer = rootView.findViewById(R.id.menuContainer); // התפריט כולו
        menuListView = rootView.findViewById(R.id.menuListView);
        btnToggleMenu = rootView.findViewById(R.id.btnToggleMenu);
        lvEvents = rootView.findViewById(R.id.lvEvents);  // ListView של האירועים

        // יצירת המערך של פריטי התפריט
        String[] menuItems = {"דף הבית", "האירועים שלי", "התנתקות"};

        // יצירת ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, menuItems);
        menuListView.setAdapter(adapter);

        // יצירת מופע של DatabaseHelper
        dbHelper = new DatabaseHelper(getActivity());

        // הוספת מאזין לכפתור שיפתח ויסגור את התפריט
        btnToggleMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(menuContainer)) {
                    drawerLayout.closeDrawer(menuContainer);
                } else {
                    drawerLayout.openDrawer(menuContainer);
                }
            }
        });

        // מאזין ללחיצה על פריט בתפריט
        menuListView.setOnItemClickListener((parent, view, position, id) -> {
            switch (position) {
                case 0:
                    // חזרה לדף הבית - פתח את HomeFragment
                    openHomeFragment();
                    break;
                case 1:
                    // האירועים שלי - הצגת רשימת האירועים
                    loadEvents();
                    break;
                case 2:
                    // התנתקות - חזרה ללוגין
                    logout();
                    break;
                default:
                    break;
            }
            drawerLayout.closeDrawer(menuContainer); // סגירת התפריט אחרי לחיצה
        });

        return rootView;
    }

    // הצגת דף הבית
    private void openHomeFragment() {
        HomeFragment homeFragment = new HomeFragment();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, homeFragment)
                .addToBackStack(null)
                .commit();
    }

    // התנתקות
    private void logout() {
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        getActivity().finish();
    }

    // טוען את האירועים ומציג אותם ב-ListView
    private void loadEvents() {
        ArrayList<String> eventList = new ArrayList<>();

        // שליפת כל האירועים מהמסד נתונים
        Cursor cursor = dbHelper.getAllEvents();  // שליפה דרך הפונקציה שהוספנו ב-DatabaseHelper
        if (cursor.moveToFirst()) {
            do {
                String title = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EVENT_NAME));
                String date = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EVENT_DATE));
                String time = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EVENT_TIME));


                // הוספת האירועים לרשימה
                eventList.add(title + " - " + date + " " + time);
            } while (cursor.moveToNext());
        }
        cursor.close();

        // הצגת האירועים ב-ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, eventList);
        lvEvents.setAdapter(adapter);  // הצגת האירועים ב-ListView הנכון
    }
}
