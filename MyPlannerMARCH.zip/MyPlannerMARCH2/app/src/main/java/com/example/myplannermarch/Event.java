package com.example.myplannermarch;
public class Event {
    private String title;
    private String date;
    private int hour;
    private int minute;
    private String reminder;

    // עדכון הקונסטרוקטור כך שיכלול 5 פרמטרים
    public Event(String title, String date, int hour, int minute, String reminder) {
        this.title = title;
        this.date = date;
        this.hour = hour;
        this.minute = minute;
        this.reminder = reminder;
    }

    // Getter methods
    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public String getReminder() {
        return reminder;
    }
}
