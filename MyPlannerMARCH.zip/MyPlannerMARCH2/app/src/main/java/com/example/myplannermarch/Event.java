package com.example.myplannermarch;
public class Event {
    private String title;
    private String date;
    private int hour;
    private int minute;
    private String reminder;
    // בנאי
    public Event(String title, String date, int hour, int minute) {
        this.title = title;
        this.date = date;
        this.hour = hour;
        this.minute = minute;
    }

    // גטרים
    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public String getReminder() {
        return reminder;
    }
}
