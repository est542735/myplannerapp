package com.example.myplannermarch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyPlanner.db";
    private static final int DATABASE_VERSION = 1;

    // טבלת משתמשים
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_PASSWORD = "password";

    private static final int MIN_PHONE_LENGTH = 9; // מינימום ספרות לטלפון
    private static final int MAX_PHONE_LENGTH = 10; // מקסימום ספרות לטלפון
    private static final int MIN_PASSWORD_LENGTH = 6; // מינימום תווים לסיסמה

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // יצירת טבלת משתמשים
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PHONE + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // **1. פונקציה להוספת משתמש חדש עם ולידציה**
    public boolean registerUser(String username, String phone, String password, Context context) {
        // בדיקת ולידציה
        if (!isValidPhone(phone)) {
            Toast.makeText(context, "מספר טלפון חייב להיות בין " + MIN_PHONE_LENGTH + " ל-" + MAX_PHONE_LENGTH + " ספרות!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!isValidPassword(password)) {
            Toast.makeText(context, "סיסמה חייבת להכיל לפחות " + MIN_PASSWORD_LENGTH + " תווים!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (isUsernameExists(username)) {
            Toast.makeText(context, "שם המשתמש כבר קיים!", Toast.LENGTH_SHORT).show();
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // אם נוסף בהצלחה, נחזיר true
    }

    // **2. פונקציה לבדיקה אם שם משתמש קיים**
    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // **3. פונקציה לבדיקה אם שם משתמש וסיסמה תואמים (כניסה)**
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // **4. פונקציה לבדיקה אם מספר טלפון תקין**
    private boolean isValidPhone(String phone) {
        return phone.matches("\\d{" + MIN_PHONE_LENGTH + "," + MAX_PHONE_LENGTH + "}");
    }

    // **5. פונקציה לבדיקה אם סיסמה עומדת בדרישות**
    private boolean isValidPassword(String password) {
        return password.length() >= MIN_PASSWORD_LENGTH;
    }
}
