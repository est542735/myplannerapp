package com.example.myplannermarch;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AddEventFragment extends Fragment {

    private static final String ARG_SELECTED_DATE = "selected_date";
    private String selectedDate;
    private DatabaseHelper databaseHelper;

    // פונקציה ליצירת מופע חדש של ה-Fragment
    public static AddEventFragment newInstance(String date) {
        AddEventFragment fragment = new AddEventFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SELECTED_DATE, date);
        fragment.setArguments(args);
        return fragment;
    }

    // אתחול משתנים, קבלת התאריך שנבחר
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedDate = getArguments().getString(ARG_SELECTED_DATE);
        }
        // יצירת מופע של ה-DatabaseHelper
        databaseHelper = new DatabaseHelper(getContext());
    }

    // יצירת המסך ולטפל בפעולות ממשק משתמש
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_add_event, container, false);

        TextView txtSelectedDate = rootView.findViewById(R.id.txtSelectedDate);
        EditText edtEventName = rootView.findViewById(R.id.edtEventName);
        TimePicker timePicker = rootView.findViewById(R.id.timePicker);
        Button btnSave = rootView.findViewById(R.id.btnSave);

        // הצגת התאריך הנבחר
        txtSelectedDate.setText("תאריך נבחר: " + selectedDate);

        // שמירת האירוע
        btnSave.setOnClickListener(v -> {
            String eventName = edtEventName.getText().toString();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();
            String eventTime = String.format("%02d:%02d", hour, minute); // פורמט השעה
            String reminderTime = calculateReminderTime(eventTime, 5); // התראה 5 דקות לפני האירוע

            if (!eventName.isEmpty()) {
                // שמירת האירוע במסד הנתונים
                boolean isSaved = databaseHelper.addEvent(selectedDate, eventName, eventTime, reminderTime);

                if (isSaved) {
                    Toast.makeText(getContext(), "האירוע נשמר בהצלחה!", Toast.LENGTH_SHORT).show();
                    // חזרה למסך הבית אחרי שמירת האירוע
                    getActivity().getSupportFragmentManager().popBackStack();
                } else {
                    Toast.makeText(getContext(), "אירע שגיאה בשמירת האירוע.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "אנא הכנס שם לאירוע.", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

    // פונקציה לחישוב זמן ההתראה
    private String calculateReminderTime(String eventTime, int minutesBefore) {
        String[] timeParts = eventTime.split(":");
        int hour = Integer.parseInt(timeParts[0]);
        int minute = Integer.parseInt(timeParts[1]);

        // חישוב התראה
        int reminderMinute = minute - minutesBefore;
        if (reminderMinute < 0) {
            reminderMinute += 60;
            hour--;
        }

        if (hour < 0) {
            hour += 24;  // טיפול במעבר יום
        }

        return String.format("%02d:%02d", hour, reminderMinute);
    }
}
