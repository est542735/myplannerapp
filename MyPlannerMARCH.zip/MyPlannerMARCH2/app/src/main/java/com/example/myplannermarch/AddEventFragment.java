package com.example.myplannermarch;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;

public class AddEventFragment extends Fragment {
    private TextView txtSelectedDate, txtEventTimeSelected, txtReminderTime;
    private EditText edtEventName;
    private Button btnSelectEventTime, btnSetReminder, btnSave;
    private ImageButton btnReturn;
    private int selectedHour = -1, selectedMinute = -1;

    // Factory method to create a new instance of the fragment
    public static AddEventFragment newInstance(String eventTitle) {
        AddEventFragment fragment = new AddEventFragment();
        Bundle args = new Bundle();
        args.putString("event_title", eventTitle);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_event, container, false);

        // Initializing the views
        txtSelectedDate = view.findViewById(R.id.txtSelectedDate);
        edtEventName = view.findViewById(R.id.edtEventName);
        txtEventTimeSelected = view.findViewById(R.id.txtEventTimeSelected);
        txtReminderTime = view.findViewById(R.id.txtReminderTime);
        btnSelectEventTime = view.findViewById(R.id.btnSelectEventTime);
        btnSetReminder = view.findViewById(R.id.btnSetReminder);
        btnSave = view.findViewById(R.id.btnSave);
        btnReturn = view.findViewById(R.id.btnReturn);

        // Set selected date text
        String selectedDate = getArguments() != null ? getArguments().getString("event_title") : "תאריך נבחר: לא נבחר";
        txtSelectedDate.setText(selectedDate);

        // Set onClickListener for the "בחר שעת אירוע" button
        btnSelectEventTime.setOnClickListener(v -> showTimePickerDialog());

        // Set onClickListener for setting reminder
        btnSetReminder.setOnClickListener(v -> {
            if (selectedHour == -1 || selectedMinute == -1) {
                Toast.makeText(getActivity(), "נא לבחור שעה להתראה", Toast.LENGTH_SHORT).show();
                return;
            }

            String eventTitle = edtEventName.getText().toString();
            if (eventTitle.isEmpty()) {
                Toast.makeText(getActivity(), "נא להזין שם לאירוע", Toast.LENGTH_SHORT).show();
                return;
            }

            setReminder(selectedHour, selectedMinute, eventTitle);
        });

        // Set onClickListener for saving the event
        btnSave.setOnClickListener(v -> {
            // בדיקה אם כל השדות מלאים
            String eventTitle = edtEventName.getText().toString();
            if (eventTitle.isEmpty()) {
                Toast.makeText(getActivity(), "נא להזין שם לאירוע", Toast.LENGTH_SHORT).show();
                return;
            }

            // בדיקה אם השעה נבחרה
            if (selectedHour == -1 || selectedMinute == -1) {
                Toast.makeText(getActivity(), "נא לבחור שעת אירוע", Toast.LENGTH_SHORT).show();
                return;
            }

            // השגת תאריך האירוע שנבחר
            String eventDate = txtSelectedDate.getText().toString(); // את תאריך האירוע אתה יכול לשמור לפי איך שאתה בוחר אותו

            // יצירת אובייקט Event (לפי המתודולוגיה שלך)
            Event event = new Event(eventTitle, eventDate, selectedHour, selectedMinute, "התראה"); // "התראה" זה יכול להיות מותאם אישית אם יש צורך

            // שמירה בבסיס הנתונים
            DatabaseHelper dbHelper = new DatabaseHelper(getContext());
            boolean isSaved = dbHelper.addEvent(event);

            // הצגת תוצאה למשתמש
            if (isSaved) {
                Toast.makeText(getActivity(), "האירוע נשמר", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "הייתה שגיאה בשמירת האירוע", Toast.LENGTH_SHORT).show();
            }
        });

        // Set onClickListener for the return button
        btnReturn.setOnClickListener(v -> getActivity().onBackPressed());

        return view;
    }

    // Show the TimePickerDialog to select the time
    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                requireContext(),
                (view, hourOfDay, minuteOfHour) -> {
                    selectedHour = hourOfDay;
                    selectedMinute = minuteOfHour;
                    txtEventTimeSelected.setText(String.format("שעת התראה: %02d:%02d", selectedHour, selectedMinute));
                },
                hour, minute, true
        );

        timePickerDialog.show();
    }

    // Set the reminder for the selected event time
    private void setReminder(int hour, int minute, String eventTitle) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);

        // If the time has already passed, set the reminder for the next day
        if (calendar.before(Calendar.getInstance())) {
            calendar.add(Calendar.DATE, 1);
        }

        // Set up the alarm
        AlarmManager alarmManager = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(getContext(), AlarmReceiver.class);
        intent.putExtra("eventName", eventTitle); // Send the event name
        intent.putExtra("eventTime", String.format("%02d:%02d", hour, minute)); // Send the event time
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Set the alarm
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            Toast.makeText(getActivity(), "התראה נקבעה ל: " + hour + ":" + minute, Toast.LENGTH_SHORT).show();
        }
    }
}
