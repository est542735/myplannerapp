package com.example.myplannerjanuary;

import java.util.ArrayList;
import java.util.List;

public class EventManeger {

    private static EventManeger instance;
    private final List<Event> eventList = new ArrayList<>();

    private EventManeger() {
        // אפשר למלא את הרשימה אם צריך בהתחלה
    }

    public static synchronized EventManeger getInstance() {
        if (instance == null) {
            instance = new EventManeger();
        }
        return instance;
    }

    public List<Event> getEventList() {
        return eventList;
    }

    public void addEvent(Event event) {
        eventList.add(event);
    }

    public void removeEvent(Event event) {
        eventList.remove(event);
    }

    public void updateEvent(Event oldEvent, Event newEvent) {
        int index = eventList.indexOf(oldEvent);
        if (index != -1) {
            eventList.set(index, newEvent);
        }
    }
}
