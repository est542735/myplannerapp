package com.example.myplannerjanuary;

public class Event {

    private String eventName;
    private String eventDescription;
    private String eventDate;
    private String eventTime; // זמן האירוע
    private String reminderTime; // זמן ההתראה
    private boolean hasReminder;

    // בונה
    public Event(String eventName, String eventDescription, String eventDate, String eventTime, String reminderTime, boolean hasReminder) {
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.reminderTime = reminderTime;
        this.hasReminder = hasReminder;
    }

    // getters and setters
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getReminderTime() {
        return reminderTime;
    }

    public void setReminderTime(String reminderTime) {
        this.reminderTime = reminderTime;
    }

    public boolean isHasReminder() {
        return hasReminder;
    }

    public void setHasReminder(boolean hasReminder) {
        this.hasReminder = hasReminder;
    }
}
