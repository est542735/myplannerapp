package com.example.myplannerjanuary;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class HelperDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyPlannerDB";
    private static final int DATABASE_VERSION = 3; // עדכון גרסה

    // טבלת משתמשים
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE = "phone";

    // טבלת אירועים
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_NAME = "event_name";
    public static final String COLUMN_EVENT_DESCRIPTION = "event_description";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String COLUMN_EVENT_TIME = "event_time"; // הוספת זמן האירוע
    public static final String COLUMN_EVENT_COMPLETED = "event_completed";
    public static final String COLUMN_HAS_REMINDER = "has_reminder"; // עמודת התראה

    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT NOT NULL, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL, " +
                    COLUMN_PHONE + " TEXT);";

    private static final String CREATE_TABLE_EVENTS =
            "CREATE TABLE " + TABLE_EVENTS + " (" +
                    COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EVENT_NAME + " TEXT NOT NULL, " +
                    COLUMN_EVENT_DESCRIPTION + " TEXT, " +
                    COLUMN_EVENT_DATE + " TEXT, " +
                    COLUMN_EVENT_TIME + " TEXT, " + // הוספת זמן האירוע
                    COLUMN_EVENT_COMPLETED + " INTEGER DEFAULT 0, " +
                    COLUMN_HAS_REMINDER + " INTEGER DEFAULT 0);"; // הוספת עמודת ההתראה

    public HelperDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_USERS);
            db.execSQL(CREATE_TABLE_EVENTS);
            Log.d("HelperDB", "Tables created successfully.");
        } catch (Exception e) {
            Log.e("HelperDB", "Error creating tables: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // הוספת עמודות נוספות כאשר יש שדרוג גרסה
        if (oldVersion < 3) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_EVENTS + " ADD COLUMN " + COLUMN_EVENT_TIME + " TEXT;");
                Log.d("HelperDB", "Column event_time added successfully.");
            } catch (Exception e) {
                Log.e("HelperDB", "Error adding event_time column: " + e.getMessage());
            }
        }
    }

    // שליפת משתמש לפי שם משתמש
    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = { username };

        return db.query(
                TABLE_USERS,   // שם הטבלה
                new String[]{COLUMN_USER_ID, COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_PHONE}, // העמודות שברצונך לשלוף
                selection,      // תנאי הבחירה
                selectionArgs,  // ערכים לתנאי הבחירה
                null,           // קבוצת הקיבוץ (GROUP BY)
                null,           // סינון (HAVING)
                null            // מיון (ORDER BY)
        );
    }

    // הוספת משתמש חדש
    public long addUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_PHONE, phone);

        // הוספת המשתמש לטבלה
        long userId = db.insert(TABLE_USERS, null, values);
        db.close();
        Log.d("HelperDB", "User added with ID: " + userId);
        return userId;
    }

    // הוספת אירוע חדש
    public long addEvent(String eventName, String eventDescription, String eventDate, String eventTime, boolean hasReminder) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DESCRIPTION, eventDescription);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_TIME, eventTime); // הוספת הזמן
        values.put(COLUMN_EVENT_COMPLETED, 0); // ברירת מחדל: לא הושלם
        values.put(COLUMN_HAS_REMINDER, hasReminder ? 1 : 0); // אם יש התראה, נכניס 1

        long eventId = -1;
        try {
            eventId = db.insert(TABLE_EVENTS, null, values);
            Log.d("HelperDB", "Event added with ID: " + eventId);
        } catch (Exception e) {
            Log.e("HelperDB", "Error inserting event: " + e.getMessage());
        } finally {
            db.close();
        }
        return eventId;
    }

    // שליפת כל האירועים
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENTS, null, null, null, null, null, COLUMN_EVENT_DATE + " ASC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Log.d("HelperDB", "Event: " + cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NAME)));
            } while (cursor.moveToNext());
        }
        return cursor;
    }

    // שליפת אירועים לפי תאריך
    public Cursor getEventsByDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_EVENT_DATE + " = ?";
        String[] selectionArgs = { date };

        return db.query(
                TABLE_EVENTS,   // שם הטבלה
                new String[]{COLUMN_EVENT_NAME, COLUMN_EVENT_DATE, COLUMN_EVENT_TIME, COLUMN_HAS_REMINDER, COLUMN_EVENT_DESCRIPTION}, // לציין את העמודות הרלוונטיות
                selection,      // תנאי הבחירה
                selectionArgs,  // ערכים לתנאי הבחירה
                null,           // קבוצת הקיבוץ (GROUP BY)
                null,           // סינון (HAVING)
                null            // מיון (ORDER BY)
        );
    }
}
