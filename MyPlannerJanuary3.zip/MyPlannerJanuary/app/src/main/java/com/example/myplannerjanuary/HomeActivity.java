package com.example.myplannerjanuary;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private RecyclerView eventRecyclerView;
    private HelperDB dbHelper;
    private CalendarAdapter calendarAdapter;
    private List<Event> eventList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // אתחול רכיבי UI
        calendarView = findViewById(R.id.calendarView);
        eventRecyclerView = findViewById(R.id.eventRecyclerView);

        // אתחול מסד הנתונים
        dbHelper = new HelperDB(this);

        // אתחול רשימת האירועים
        eventList = new ArrayList<>();

        // הגדרת RecyclerView
        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        calendarAdapter = new CalendarAdapter(eventList);
        eventRecyclerView.setAdapter(calendarAdapter);

        // הגדרת פעולה לבחירת תאריך בלוח השנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // יצירת Intent ל-AddEventActivity עם התאריך שנבחר
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;

            // יצירת Intent
            Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);
            intent.putExtra("year", year);
            intent.putExtra("month", month);
            intent.putExtra("day", dayOfMonth);
            startActivity(intent);

            // הצגת האירועים המתאימים לתאריך שנבחר
            displayEventsForDate(selectedDate);
        });

        // טען את כל האירועים כברירת מחדל
        displayAllEvents();
    }

    private void displayAllEvents() {
        // שליפת כל האירועים מהמסד
        Cursor cursor = dbHelper.getAllEvents();
        loadEventsFromCursor(cursor);
    }

    private void displayEventsForDate(String date) {
        // שליפת אירועים לפי תאריך
        Cursor cursor = dbHelper.getEventsByDate(date);
        loadEventsFromCursor(cursor);
    }

    private void loadEventsFromCursor(Cursor cursor) {
        // נקה את הרשימה הקיימת
        eventList.clear();
        if (cursor != null && cursor.getCount() > 0) {
            // עבור על כל הרשומות והוסף אותם לרשימת האירועים
            while (cursor.moveToNext()) {
                String eventName = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_NAME));
                String eventDate = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_DATE));
                String eventTime = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_TIME));
                boolean hasReminder = cursor.getInt(cursor.getColumnIndex(HelperDB.COLUMN_HAS_REMINDER)) == 1;

                Event event = new Event(eventName, eventDate, eventTime, "No Description", "No Location", hasReminder);

                eventList.add(event);
            }
            cursor.close();
        } else {
            Toast.makeText(this, "No events found", Toast.LENGTH_SHORT).show();
        }

        // עדכון ה-RecyclerView
        calendarAdapter.notifyDataSetChanged();
    }
}
