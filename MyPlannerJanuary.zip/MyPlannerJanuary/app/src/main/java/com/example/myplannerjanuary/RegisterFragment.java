package com.example.myplannerjanuary;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class RegisterFragment extends Fragment {

    private EditText phoneEditText, usernameEditText, passwordEditText;
    private ImageButton eyeButton;
    private Button registerButton, backToLoginButton;
    private HelperDB helperDB;

    private boolean isPasswordVisible = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // קישור לקובץ ה-XML המתאים לרישום
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // קישור בין המשתנים לשדות ב-XML
        phoneEditText = view.findViewById(R.id.phoneEditText);
        usernameEditText = view.findViewById(R.id.usernameEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        eyeButton = view.findViewById(R.id.eyeButton);
        registerButton = view.findViewById(R.id.registerButton);
        backToLoginButton = view.findViewById(R.id.backToLoginButton);

        // יצירת מופע של HelperDB
        helperDB = new HelperDB(getActivity());

        // שמיעה לאירוע לחיצה על כפתור הרישום
        registerButton.setOnClickListener(v -> handleRegister());

        // שמיעה לכפתור עין לצורך הצגת סיסמה או הסתרתה
        eyeButton.setOnClickListener(v -> togglePasswordVisibility());

        // שמיעה לאירוע לחיצה על כפתור חזרה ללוגין
        backToLoginButton.setOnClickListener(v -> goToLoginFragment());

        return view;
    }

    // פונקציה לביצוע רישום המשתמש
    private void handleRegister() {
        String phone = phoneEditText.getText().toString().trim();
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // בדיקת שדות ריקים
        if (TextUtils.isEmpty(phone) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "נא למלא את כל השדות", Toast.LENGTH_SHORT).show();
            return;
        }

        // הוספת המשתמש למסד הנתונים
        long userId = helperDB.addUser(username, password, phone);

        if (userId != -1) {
            // אם הרישום הצליח, נעבור לאקיביטי הבית
            Intent intent = new Intent(requireActivity(), HomeActivity.class);  // ייצור Intent לאקיביטי הבית
            startActivity(intent);
            requireActivity().finish();  // סוגר את האקטיביטי הנוכחי (RegisterFragment)
        } else {
            Toast.makeText(getActivity(), "הרישום נכשל", Toast.LENGTH_SHORT).show();
        }
    }

    // פונקציה להצגת/הסתרת הסיסמה
    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordEditText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
            isPasswordVisible = false;
        } else {
            passwordEditText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            isPasswordVisible = true;
        }

        // עדכון הקלט אחרי השינוי
        passwordEditText.setSelection(passwordEditText.getText().length()); // מוודא שהסמן נשאר בסוף השדה
    }

    // פונקציה למעבר ללוגין פרגמנט
    private void goToLoginFragment() {
        LoginFragment loginFragment = new LoginFragment();
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, loginFragment)  // החלפת פרגמנט
                .addToBackStack(null)  // מאפשר חזרה למסך הקודם
                .commit();
    }
}
