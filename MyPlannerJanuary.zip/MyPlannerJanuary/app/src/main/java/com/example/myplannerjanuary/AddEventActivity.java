package com.example.myplannerjanuary;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class AddEventActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "event_reminder_channel";
    private static final String CHANNEL_NAME = "Event Reminder Channel";
    private static final String CHANNEL_DESCRIPTION = "Channel for event reminders";

    private TextView dateTextView;
    private TimePicker timePicker;
    private EditText eventNameEditText;
    private Button saveEventButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dateTextView = findViewById(R.id.dateTextView);
        timePicker = findViewById(R.id.timePicker);
        eventNameEditText = findViewById(R.id.eventNameEditText);
        saveEventButton = findViewById(R.id.saveEventButton);

        // יצירת ערוץ התראות אם הגרסה היא 8 ומעלה
        createNotificationChannel();

        // בקשת הרשאות עבור התראות (בהתאם לגרסה)
        requestNotificationPermission();

        // קבלת הנתונים מה-Intent
        Intent intent = getIntent();
        int year = intent.getIntExtra("year", -1);
        int month = intent.getIntExtra("month", -1);
        int day = intent.getIntExtra("day", -1);

        // הצגת התאריך
        dateTextView.setText("Selected Date: " + day + "/" + (month + 1) + "/" + year);

        // כפתור שמירת האירוע
        saveEventButton.setOnClickListener(v -> {
            String eventName = eventNameEditText.getText().toString();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            // קביעת התראה אם ההרשאה ניתנה
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED) {
                setReminder(year, month, day, hour, minute);
                finish(); // חזרה ל-HomeActivity לאחר שמירת האירוע
            } else {
                Toast.makeText(this, "Notification permission is required.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // יצירת ערוץ התראה
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // יצירת ערוץ עם הגדרה של שם, תיאור וחשיבות
            CharSequence name = CHANNEL_NAME;
            String description = CHANNEL_DESCRIPTION;
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // השגת NotificationManager והוספת הערוץ
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private void setReminder(int year, int month, int day, int hour, int minute) {
        try {
            // יצירת תאריך לשעת ההתראה
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("eventName", eventNameEditText.getText().toString());
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            // הגדרת AlarmManager להפעיל את ההתראה בזמן שנבחר
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            if (alarmManager != null) {
                // אם ה-AlarmManager קיים, הגדרת ההתראה
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

                // הצגת הודעת טוסט אם ההתראה הוגדרה בהצלחה
                Toast.makeText(this, "Reminder set successfully!", Toast.LENGTH_SHORT).show();
            } else {
                // אם ה-AlarmManager לא קיים, הצגת הודעת טוסט שגיאה
                Log.e("AddEventActivity", "AlarmManager is null");
                Toast.makeText(this, "Failed to set reminder.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("AddEventActivity", "Error setting reminder: " + e.getMessage());
            Toast.makeText(this, "An error occurred while setting the reminder.", Toast.LENGTH_SHORT).show();
        }
    }



    // בקשת הרשאות עבור התראות (בהתאם לגרסה)
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // אם הגרסה היא אנדרואיד 13 ומעלה, נוודא שההרשאה ניתנה
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }
    }

    // טיפול בתגובה של המשתמש לבקשה הרשאה
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // ההרשאה ניתנה, ניתן לשלוח התראות
                Toast.makeText(this, "Permission granted for notifications.", Toast.LENGTH_SHORT).show();
            } else {
                // ההרשאה לא ניתנה
                Toast.makeText(this, "Permission denied for notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
