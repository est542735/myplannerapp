package com.example.myplannerjanuary;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;

public class AddEventFragment extends Fragment {

    private EditText eventNameEditText;
    private Button chooseDateButton;
    private TextView selectedDateTextView;
    private Button setReminderButton;
    private Button saveEventButton;
    private TimePicker reminderTimePicker;

    private int selectedYear, selectedMonth, selectedDay;
    private Calendar eventCalendar;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_add_event, container, false);

        // Initialize views
        eventNameEditText = rootView.findViewById(R.id.eventNameEditText);
        chooseDateButton = rootView.findViewById(R.id.chooseDateButton);
        selectedDateTextView = rootView.findViewById(R.id.selectedDateTextView); // Now includes TextView
        setReminderButton = rootView.findViewById(R.id.setReminderButton);
        reminderTimePicker = rootView.findViewById(R.id.reminderTimePicker);
        saveEventButton = rootView.findViewById(R.id.saveEventButton);

        // Set TimePicker to 24-hour format
        reminderTimePicker.setIs24HourView(true);

        // Get today's date
        Calendar calendar = Calendar.getInstance();
        selectedYear = calendar.get(Calendar.YEAR);
        selectedMonth = calendar.get(Calendar.MONTH);
        selectedDay = calendar.get(Calendar.DAY_OF_MONTH);

        // Display today's date by default
        selectedDateTextView.setText(String.format("%d/%d/%d", selectedDay, selectedMonth + 1, selectedYear));

        // Set onClick listeners
        chooseDateButton.setOnClickListener(view -> openDatePickerDialog());
        setReminderButton.setOnClickListener(view -> toggleReminderTimePicker());
        saveEventButton.setOnClickListener(view -> setEventReminder());

        return rootView;
    }

    private void openDatePickerDialog() {
        // Open DatePickerDialog to choose a date
        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                (view, year, month, dayOfMonth) -> {
                    selectedYear = year;
                    selectedMonth = month;
                    selectedDay = dayOfMonth;
                    selectedDateTextView.setText(String.format("%d/%d/%d", selectedDay, selectedMonth + 1, selectedYear));
                }, selectedYear, selectedMonth, selectedDay);
        datePickerDialog.show();
    }

    private void toggleReminderTimePicker() {
        // Show or hide the reminder TimePicker
        if (reminderTimePicker.getVisibility() == View.VISIBLE) {
            reminderTimePicker.setVisibility(View.GONE);
        } else {
            reminderTimePicker.setVisibility(View.VISIBLE);
        }
    }

    private void setEventReminder() {
        String eventName = eventNameEditText.getText().toString().trim();
        if (eventName.isEmpty()) {
            Toast.makeText(requireContext(), "יש להזין שם לאירוע", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set the reminder time
        eventCalendar = Calendar.getInstance();
        eventCalendar.set(Calendar.YEAR, selectedYear);
        eventCalendar.set(Calendar.MONTH, selectedMonth);
        eventCalendar.set(Calendar.DAY_OF_MONTH, selectedDay);
        eventCalendar.set(Calendar.HOUR_OF_DAY, reminderTimePicker.getHour());
        eventCalendar.set(Calendar.MINUTE, reminderTimePicker.getMinute());
        eventCalendar.set(Calendar.SECOND, 0);

        // Create intent to trigger the reminder
        Intent intent = new Intent(requireContext(), AlarmReceiver.class);
        intent.putExtra("eventName", eventName);

        // Create PendingIntent
        PendingIntent pendingIntent = PendingIntent.getBroadcast(requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Set the alarm with AlarmManager
        AlarmManager alarmManager = (AlarmManager) requireContext().getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, eventCalendar.getTimeInMillis(), pendingIntent);
            Toast.makeText(requireContext(), "האירוע נשמר עם התראה", Toast.LENGTH_SHORT).show();
        }
    }
}
