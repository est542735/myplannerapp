package com.example.myplannerjanuary;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String eventName = intent.getStringExtra("eventName");
        if (eventName == null || eventName.isEmpty()) {
            eventName = "Unnamed Event"; // ברירת מחדל אם לא הוזן שם לאירוע
        }

        // יצירת Intent שיתבצע כשמשתמש ילחץ על ההתראה
        Intent notificationIntent = new Intent(context, HomeActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // יצירת PendingIntent עבור ההתראה
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // דגלים מתאימים לגרסאות מודרניות
        );

        // יצירת התראה
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, AddEventActivity.CHANNEL_ID)
                .setSmallIcon(R.drawable.logo) // אייקון ההתראה (הקפד שהמשאב קיים בתיקיית res/drawable)
                .setContentTitle("Reminder: " + eventName) // כותרת ההתראה
                .setContentText("Your event is scheduled now.") // תוכן ההתראה
                .setPriority(NotificationCompat.PRIORITY_HIGH) // עדיפות גבוהה
                .setContentIntent(pendingIntent) // Intent שיפתח את HomeActivity
                .setAutoCancel(true); // הסרה אוטומטית של ההתראה לאחר לחיצה

        // הצגת ההתראה
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            // מזהה ייחודי להתראה
            notificationManager.notify((int) System.currentTimeMillis(), notificationBuilder.build());
        }
    }
}
