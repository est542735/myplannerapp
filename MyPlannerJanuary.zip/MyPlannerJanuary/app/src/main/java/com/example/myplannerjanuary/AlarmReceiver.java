package com.example.myplannerjanuary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.widget.Toast;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // קבלת שם האירוע מתוך ה-Intent
        String eventName = intent.getStringExtra("eventName");

        // הצגת הודעה בהתראה
        Toast.makeText(context, "התראה: " + eventName, Toast.LENGTH_LONG).show();

        // הוספת אפשרות לנגן צליל בעת התראה
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent ringtoneIntent = new Intent(Intent.ACTION_VIEW, soundUri);
        context.startActivity(ringtoneIntent);
    }
}
