package com.example.myplannerjanuary;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.CalendarView;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;

public class HomeActivity extends AppCompatActivity {

    private CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // יצירת NotificationChannel אם הגרסה היא Android 8 ומעלה
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = AddEventActivity.CHANNEL_ID;
            CharSequence name = "Event Reminder Notifications";
            String description = "Notifications for scheduled events";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(channelId, name, importance);
            channel.setDescription(description);

            // קבלת NotificationManager ויצירת הערוץ
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        // קישור ל-CalendarView
        calendarView = findViewById(R.id.calendarView);

        // הגדרת פעולה לבחירת תאריך
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // יצירת Intent ל-AddEventActivity עם התאריך שנבחר
            Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);
            intent.putExtra("year", year);
            intent.putExtra("month", month);
            intent.putExtra("day", dayOfMonth);
            startActivity(intent);
        });
    }
}
