package com.example.myplannerjanuary;

import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class HomeActivity extends AppCompatActivity {

    private CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        calendarView = findViewById(R.id.calendarView);

        // הוספת מאזין למעבר בין הימים בלוח השנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            openAddEventFragment(year, month, dayOfMonth);
        });
    }

    private void openAddEventFragment(int year, int month, int dayOfMonth) {
        // הסתיר את כל התצוגות של ה-Activity לפני הצגת הפרגמנט
        findViewById(R.id.todayDateTextView).setVisibility(View.GONE);
        findViewById(R.id.calendarView).setVisibility(View.GONE);
        findViewById(R.id.upcomingTasksTextView).setVisibility(View.GONE);
        findViewById(R.id.upcomingTasksButton).setVisibility(View.GONE);
        findViewById(R.id.upcomingTasksRecyclerView).setVisibility(View.GONE);

        // יצירת Bundle עם תאריך שנבחר
        Bundle bundle = new Bundle();
        bundle.putInt("year", year);
        bundle.putInt("month", month);
        bundle.putInt("day", dayOfMonth);

        // יצירת הפרגמנט ותחבירו
        AddEventFragment addEventFragment = new AddEventFragment();
        addEventFragment.setArguments(bundle);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, addEventFragment);
        transaction.addToBackStack(null);  // מאפשר חזרה למסך הקודם
        transaction.commit();
    }
}
