package com.example.myplannerjanuary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CalendarView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        calendarView = findViewById(R.id.calendarView);

        // מאזין לבחירת יום בלוח השנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            openAddEventActivity(year, month, dayOfMonth);
        });
    }

    private void openAddEventActivity(int year, int month, int dayOfMonth) {
        // יצירת Intent עבור הפעולה החדשה
        Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);

        // הוספת התאריך שנבחר ל-Intent
        intent.putExtra("year", year);
        intent.putExtra("month", month);
        intent.putExtra("day", dayOfMonth);

        // הפעלת ה-Activity
        startActivity(intent);
    }
}
