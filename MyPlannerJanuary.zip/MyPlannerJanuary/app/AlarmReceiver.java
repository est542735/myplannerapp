package com.example.myplannerjanuary;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String eventName = intent.getStringExtra("eventName");

        // Create notification for the event
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "event_channel")
                .setSmallIcon(R.drawable.ic_event)  // החלף באייקון מתאים
                .setContentTitle("האירוע " + eventName + " מתקרב!")
                .setContentText("הגיע הזמן להתחיל את האירוע שלך.")
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
        notificationManager.notify(0, builder.build());
    }
}

