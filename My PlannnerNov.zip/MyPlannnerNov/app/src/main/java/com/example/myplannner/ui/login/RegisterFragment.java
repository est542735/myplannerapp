package com.example.myplannner.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.myplannner.HelperDB;
import com.example.myplannner.R;

public class RegisterFragment extends Fragment {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button registerButton;
    private Button returnButton;
    private ImageButton eyeButton;
    private boolean isPasswordVisible = false;

    private HelperDB helperDB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // ניפוח הפרגמנט REGISTER
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // אתחול של רכיבי ה-UI
        usernameEditText = view.findViewById(R.id.usernameEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        registerButton = view.findViewById(R.id.registerButton);
        returnButton = view.findViewById(R.id.ReturnButton);
        eyeButton = view.findViewById(R.id.eyeButton); // אתחול של כפתור העין

        // יצירת  HelperDB
        helperDB = new HelperDB(requireContext());

        // הגדרת מאזין לכפתור הרישום
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleRegister(); // טיפול ברישום משתמש
            }
        });

        // הגדרת מאזין לכפתור החזרה
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToLoginFragment(); // חזרה למסך הלוגין
            }
        });

        // הגדרת מאזין לכפתור העין
        eyeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility(); // החלפת סוג שדה הסיסמה
            }
        });

        return view;
    }

    // פונקציה לטיפול בלחיצה על כפתור הרישום
    private void handleRegister() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // בדיקה אם השדות ריקים
        if (TextUtils.isEmpty(username)) {
            usernameEditText.setError("Please enter a username");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordEditText.setError("Please enter a password");
            return;
        }

        // בדיקה אם שם המשתמש כבר קיים
        if (helperDB.isUsernameExists(username)) {
            usernameEditText.setError("Username already exists");
            return;
        }

        // הוספת המשתמש לבסיס הנתונים
        boolean success = helperDB.addUser(username, password);
        Log.d("RegisterFragment", "User added: " + success);  // לוג לבדוק אם ההוספה הצליחה

        if (success) {
            Toast.makeText(getContext(), "Registration successful!", Toast.LENGTH_SHORT).show();

            // מעבר ל-HomeActivity
            try {
                Intent intent = new Intent(getActivity(), HomeActivity.class);  // השתמש ב getActivity()
                startActivity(intent);
            } catch (Exception e) {
                Log.e("RegisterFragment", "Error starting HomeActivity", e);
            }
        } else {
            Toast.makeText(getContext(), "Registration failed. Try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // פונקציה להחלפת פירגמנט חזרה ללוגין
    private void navigateToLoginFragment() {
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new LoginFragment())
                .commit();
    }

    // פונקציה להחלפת הצגת הסיסמה
    private void togglePasswordVisibility() {
        // אם הסיסמה מוצגת - הסתר אותה
        if (isPasswordVisible) {
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            eyeButton.setImageResource(R.drawable.closedeye);
        } else {
            // אם הסיסמה מוסתרת הצג אותה
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            eyeButton.setImageResource(R.drawable.closedeye);
        }

        isPasswordVisible = !isPasswordVisible; // עדכון מצב הסיסמה
        passwordEditText.setSelection(passwordEditText.getText().length()); // מוודא שהעכבר נמצא בסוף
    }
}
