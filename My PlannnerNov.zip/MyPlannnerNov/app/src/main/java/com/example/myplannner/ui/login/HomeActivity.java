package com.example.myplannner.ui.login;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.CalendarView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.example.myplannner.R;

public class HomeActivity extends AppCompatActivity {

    private TextView todayDateTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // הגדרת ה-TextView שמציג את התאריך
        todayDateTextView = findViewById(R.id.todayDate);

        // עדכון התאריך בהתחלה
        updateDate();

        // הגדרת לוח שנה (CalendarView)
        CalendarView calendarView = findViewById(R.id.calendarView);

        // הגדרת התאריך הנוכחי בלוח השנה
        Calendar calendar = Calendar.getInstance();
        calendarView.setDate(calendar.getTimeInMillis(), true, true); // עדכון לוח השנה לתאריך הנוכחי

        // הגדרת מאזין לשינוי תאריך בלוח שנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // עדכון התאריך שמוצג ב-TextView כאשר המשתמש בוחר תאריך
            String selectedDate = String.format("%02d.%02d.%04d", dayOfMonth, month + 1, year); // פורמט "יום.חודש.שנה"
            todayDateTextView.setText(selectedDate);
        });
    }

    // פונקציה לעדכון התאריך
    private void updateDate() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy"); // פורמט "יום.חודש.שנה"
        String currentDate = sdf.format(calendar.getTime());
        todayDateTextView.setText(currentDate);
    }
}
