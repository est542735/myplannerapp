package com.example.myplannner;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myplannner.ui.login.LoginFragment;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //  בודקים אם זו הפעם הראשונה שהמסך נפתח
        if (savedInstanceState == null) {
            // אם זה המסך הראשון נטעין את מסך הכניסה
            getSupportFragmentManager().beginTransaction() //  פעולה שמנהלת מסכים בתוך המסך הנוכחי
                    .replace(
                            R.id.fragment_container, // המקום בו יהיה הפרגמנט
                            new LoginFragment()     //  יוצרים מסך כניסה חדש פרגמנט לוגין
                    )
                    .commit(); // הפעולה מתבצעת בפועל כאן
        }
    }
}
