package com.example.myplannner;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // משתנה לייצוג הלוגו
    private ImageView logoImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // קישור בין משתנה הלוגו לXML
        logoImageView = findViewById(R.id.logoImageView);

        // הפעלת אנימציה ללוגו
        startLogoAnimation();

        // הפעלת טיימר  3 שניות מעביר למסך ההתחברות
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class); // מעבר למסך ההתחברות
            startActivity(intent); // הפעלת הלוגין אקטיביטי
            finish(); // סיום הפעילות הנוכחית כדי למנוע חזרה למסך הפתיחה
        }, 3000);
    }

    /*** מפעילה אנימציה פשוטה על הלוגו */
    private void startLogoAnimation() {
        logoImageView.animate()
                .scaleX(1.2f) // הגדלה על ציר X ב-20%
                .scaleY(1.2f) // הגדלה על ציר Y ב-20%
                .rotation(360f) // סיבוב מלא של התמונה
                .setDuration(2000); // משך האנימציה ב-מילישניות
    }
}
