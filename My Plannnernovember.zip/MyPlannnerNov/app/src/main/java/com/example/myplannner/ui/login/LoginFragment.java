package com.example.myplannner.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.myplannner.HelperDB;
import com.example.myplannner.R;

public class LoginFragment extends Fragment {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private TextView loginTextView;
    private ImageButton eyeButton;
    private boolean isPasswordVisible = false;

    private HelperDB helperDB;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //   ניפוח  הפרגמנט לוגין
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // אתחול של רכיבי ה-UI
        usernameEditText = view.findViewById(R.id.usernameEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        loginButton = view.findViewById(R.id.loginButton);
        registerButton = view.findViewById(R.id.RegisterButton);
        loginTextView = view.findViewById(R.id.loginTextView);
        eyeButton = view.findViewById(R.id.eyeButton);

        // יצירת HelperDB
        helperDB = new HelperDB(getContext());

        // הגדרת מאזין לכפתור הלוגין
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin(); // טיפול בלחיצה על כפתור הלוגין
            }
        });

        // הגדרת מאזין לכפתור הרישום
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleRegister(); // טיפול בלחיצה על כפתור הרישום
            }
        });

        // מאזין לכפתור העין
        eyeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();  // החלף בין מצב סיסמה מוסתרת ומוצגת
            }
        });

        return view;
    }

    // פונקציה להחלפת מצב הסיסמה בין מוצגת ומוסתרת
    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            eyeButton.setImageResource(R.drawable.closedeye);  // עדכון אייקון עין סגורה
        } else {
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            eyeButton.setImageResource(R.drawable.closedeye);  // עדכון אייקון עין פתוחה
        }
        isPasswordVisible = !isPasswordVisible;  // עדכון מצב הסיסמה
    }

    // פונקציה לטיפול בלחיצה על כפתור הלוגין
    private void handleLogin() {
        String username = usernameEditText.getText().toString(); // מקבל את שם המשתמש
        String password = passwordEditText.getText().toString(); // מקבל את הסיסמה

        // בדיקה אם השדות ריקים
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            // הצגת הודעת שגיאה במידה והמשתמש לא מילא את השדות
            if (TextUtils.isEmpty(username)) {
                usernameEditText.setError("Please enter a username");
            }
            if (TextUtils.isEmpty(password)) {
                passwordEditText.setError("Please enter a password");
            }
            return;
        }

        // בדיקה אם נתוני הלוגין נכונים על פי מה שנמצא בבסיס הנתונים
        if (helperDB.authenticateUser(username, password)) {
            // אם נתוני הלוגין נכונים, נוודא את המעבר ל-HomeActivity
            navigateToHomeActivity();
        } else {
            // הצגת הודעת שגיאה אם נתוני הלוגין לא נכונים
            usernameEditText.setError("Invalid username or password");
            passwordEditText.setError("Invalid username or password");  // הצגת שגיאה גם עבור הסיסמה

            // הצגת טוסט עבור שגיאה
            Toast.makeText(getContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // פונקציה למעבר למסך הבית אחרי לוגין מוצלח
    private void navigateToHomeActivity() {
        Toast.makeText(getContext(), "Login successful!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getActivity(), HomeActivity.class);
        startActivity(intent);
        getActivity().finish(); // סגירת האקטיביטי הנוכחית
    }

    // פונקציה לטיפול בלחיצה על כפתור הרישום
    private void handleRegister() {
        RegisterFragment registerFragment = new RegisterFragment();

        // החלפת פרגמנט למסך הרישום
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, registerFragment);
        transaction.addToBackStack(null); //   הוספת הפירגמנט להיסטוריית ה-back כך המשתמש יוכל לחזור
        transaction.commit();
    }
}
