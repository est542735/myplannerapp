package com.example.myplannner;

// ייבוא מחלקות שדרושות לניהול בסיס נתונים, אבטחה ותפעול
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

// מחלקה שמנהלת את כל העבודה עם בסיס הנתונים
public class HelperDB extends SQLiteOpenHelper {

    // שם בסיס הנתונים והגרסה שלו
    private static final String DATABASE_NAME = "my_planner_db"; // שם קובץ בסיס הנתונים
    private static final int DATABASE_VERSION = 1; // גרסת בסיס הנתונים

    // הגדרות הטבלה שתשמור משתמשים
    public static final String TABLE_USERS = "users"; // שם הטבלה
    public static final String COLUMN_ID = "id"; //  מזהה ייחודי לכל משתמש
    public static final String COLUMN_USERNAME = "username"; // שם משתמש
    public static final String COLUMN_PASSWORD = "password"; // סיסמה

    // שורת SQL שמגדירה איך תיראה הטבלה
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + // עמודת מזהה שנוצרת אוטומטית
            COLUMN_USERNAME + " TEXT UNIQUE, " + // שם משתמש חייב להיות ייחודי
            COLUMN_PASSWORD + " TEXT)"; // עמודת סיסמאות

    // בנאי המחלקה
    public HelperDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // פונקציה שנקראת כשבונים את בסיס הנתונים בפעם הראשונה
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE); // יוצר את טבלת המשתמשים
    }

    // פונקציה שמופעלת אם גרסת בסיס הנתונים משתנה
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS); // מוחקים את הטבלה הקיימת
        onCreate(db); // יוצרים מחדש את הטבלה
    }

    // פונקציה שמוסיפה משתמש חדש לבסיס הנתונים
    public boolean addUser(String username, String password) {
        // בדיקה אם שם המשתמש או הסיסמה ריקים, או אם שם המשתמש כבר קיים
        if (username.isEmpty() || password.isEmpty() || isUsernameExists(username)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase(); // פותחים בסיס נתונים לכתיבה
        ContentValues values = new ContentValues(); // מכינים ערכים להוספה
        values.put(COLUMN_USERNAME, username); // מוסיפים שם משתמש
        values.put(COLUMN_PASSWORD, hashPassword(password)); // מוסיפים סיסמה אחרי הצפנה

        long result = db.insert(TABLE_USERS, null, values); // מוסיפים לטבלה
        db.close(); // סוגרים את החיבור לבסיס הנתונים
        return result != -1; // אם ההוספה הצליחה מחזירים true
    }

    // פונקציה שבודקת אם שם משתמש כבר קיים
    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase(); // פותחים בסיס נתונים לקריאה
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID}, COLUMN_USERNAME + " = ?",
                    new String[]{username}, null, null, null);
            return cursor.getCount() > 0; // אם נמצאו תוצאות, השם כבר קיים
        } finally {
            if (cursor != null) cursor.close(); // סוגרים את הקריאה
        }
    }

    // פונקציה שמצפינה סיסמה בעזרת SHA-256
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); // יוצרים אובייקט להצפנה
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8)); // מצפינים את הסיסמה
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString(); // מחזירים את הסיסמה המוצפנת
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e); // טיפול בשגיאות
        }
    }

    // פונקציה שמחזירה את כל המשתמשים בטבלה
    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase(); // פותחים בסיס נתונים לקריאה
        return db.query(TABLE_USERS, new String[]{COLUMN_ID, COLUMN_USERNAME}, null, null, null, null, null);
    }

    // פונקציה שמעדכנת שם משתמש וסיסמה לפי מזהה משתמש
    public int updateUser(int id, String newUsername, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, newUsername); // מעדכנים שם משתמש
        values.put(COLUMN_PASSWORD, hashPassword(newPassword)); // מעדכנים סיסמה (מוצפנת)
        return db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // פונקציה שמוחקת משתמש לפי מזהה
    public void deleteUser(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)}); // מחיקה לפי ID
        db.close();
    }

    // פונקציה שמאמתת שם משתמש וסיסמה
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // מצפינים את הסיסמה שהוזנה
        String hashedPassword = hashPassword(password);

        // מחפשים את המשתמש עם הסיסמה המוצפנת
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, hashedPassword});

        if (cursor != null && cursor.moveToFirst()) {
            cursor.close();
            return true; // ההזדהות הצליחה
        } else {
            if (cursor != null) cursor.close();
            return false; // ההזדהות נכשלה
        }
    }
}
