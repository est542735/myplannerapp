package com.example.myplanner;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
public class AddEventActivity extends AppCompatActivity {
    EditText titleInput;
    Button dateButton, timeButton, saveButton;
    Spinner colorSpinner;
    DatabaseHelper dbHelper;

    String selectedDate = "", selectedTime = "", selectedColor = "#FF0000"; // ברירת מחדל

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        titleInput = findViewById(R.id.titleInput);
        dateButton = findViewById(R.id.dateButton);
        timeButton = findViewById(R.id.timeButton);
        colorSpinner = findViewById(R.id.colorSpinner);
        saveButton = findViewById(R.id.saveButton);
        dbHelper = new DatabaseHelper(this);

        // צבעים לדוגמה
        String[] colors = {"#FF0000", "#00FF00", "#0000FF", "#FFA500"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, colors);
        colorSpinner.setAdapter(adapter);

        dateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
                selectedDate = year + "-" + (month + 1) + "-" + day;
                dateButton.setText(selectedDate);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            picker.show();
        });

        timeButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog picker = new TimePickerDialog(this, (view, hour, minute) -> {
                selectedTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
                timeButton.setText(selectedTime);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
            picker.show();
        });

        saveButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString();
            selectedColor = colorSpinner.getSelectedItem().toString();
            if (!title.isEmpty() && !selectedDate.isEmpty()) {
                dbHelper.insertEvent(title, selectedDate, selectedTime, selectedColor);
                Toast.makeText(this, "אירוע נשמר!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "נא למלא את כל השדות", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
