package com.example.myplanner;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.ViewHolder> {
    private List<Event> events;
    private Context context;

    public interface OnEventClickListener {
        void onEdit(Event event);
        void onDelete(Event event);
    }

    private OnEventClickListener listener;

    public EventsAdapter(Context context, List<Event> events, OnEventClickListener listener) {
        this.context = context;
        this.events = events;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, time;
        View colorTag;
        ImageButton editBtn, deleteBtn;

        public ViewHolder(View v) {
            super(v);
            title = v.findViewById(R.id.eventTitle);
            time = v.findViewById(R.id.eventTime);
            colorTag = v.findViewById(R.id.colorTag);
            editBtn = v.findViewById(R.id.editButton);
            deleteBtn = v.findViewById(R.id.deleteButton);
        }
    }

    @Override
    public EventsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Event e = events.get(position);
        holder.title.setText(e.title);
        holder.time.setText(e.time);
        holder.colorTag.setBackgroundColor(Color.parseColor(e.color));
        holder.editBtn.setOnClickListener(v -> listener.onEdit(e));
        holder.deleteBtn.setOnClickListener(v -> listener.onDelete(e));
    }

    @Override
    public int getItemCount() {
        return events.size();
    }
}
