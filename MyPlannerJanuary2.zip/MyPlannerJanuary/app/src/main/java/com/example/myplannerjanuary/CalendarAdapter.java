package com.example.myplannerjanuary;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.EventViewHolder> {

    private List<Event> eventDetails; // רשימה של אובייקטי Event

    // Constructor
    public CalendarAdapter(List<Event> eventDetails) {
        this.eventDetails = eventDetails;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the view for each list item
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Bind data to the view
        Event event = eventDetails.get(position);
        holder.eventNameTextView.setText(event.getEventName());
        holder.eventDetailsTextView.setText("Date: " + event.getEventDate() + " | Time: " + event.getEventTime());
    }

    @Override
    public int getItemCount() {
        return eventDetails != null ? eventDetails.size() : 0;  // Return size of the list, ensuring no null pointer exception
    }

    // ViewHolder class to hold the view for each list item
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventNameTextView;
        TextView eventDetailsTextView;

        public EventViewHolder(View itemView) {
            super(itemView);
            eventNameTextView = itemView.findViewById(android.R.id.text1);
            eventDetailsTextView = itemView.findViewById(android.R.id.text2);
        }
    }
}
