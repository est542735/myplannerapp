package com.example.myplannerjanuary;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private RecyclerView eventRecyclerView;
    private HelperDB dbHelper;
    private CalendarAdapter calendarAdapter;
    private List<Event> eventList;
    private static final String CHANNEL_ID = "event_reminder_channel"; // Channel ID for notifications

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // יצירת NotificationChannel אם הגרסה היא Android 8 ומעלה
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Event Reminder Notifications";
            String description = "Notifications for scheduled events";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        // אתחול רכיבי UI
        calendarView = findViewById(R.id.calendarView);
        eventRecyclerView = findViewById(R.id.eventRecyclerView);

        // אתחול מסד הנתונים
        dbHelper = new HelperDB(this);

        // אתחול רשימת האירועים
        eventList = new ArrayList<>();

        // הגדרת RecyclerView
        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        calendarAdapter = new CalendarAdapter(eventList);
        eventRecyclerView.setAdapter(calendarAdapter);

        // הגדרת פעולה לבחירת תאריך בלוח השנה
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // יצירת Intent ל-AddEventActivity עם התאריך שנבחר
            Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);
            intent.putExtra("year", year);
            intent.putExtra("month", month);
            intent.putExtra("day", dayOfMonth);
            startActivity(intent);

            // יצירת תאריך כמות של "yyyy-MM-dd" שנשלח למסד הנתונים
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
            displayEventsForDate(selectedDate);
        });

        // טען את כל האירועים כברירת מחדל
        displayAllEvents();
    }

    private void displayEventsForDate(String date) {
        Cursor cursor = dbHelper.getEventsByDate(date);
        loadEventsFromCursor(cursor);
    }

    private void displayAllEvents() {
        Cursor cursor = dbHelper.getAllEvents();
        loadEventsFromCursor(cursor);
    }

    private void loadEventsFromCursor(Cursor cursor) {
        eventList.clear();

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String eventName = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_NAME));
                String eventDate = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_DATE));
                String eventTime = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_EVENT_TIME));

                Event event = new Event(eventName, eventDate, eventTime);
                eventList.add(event);

                // יצירת התראה אם יש Reminder
                int reminderColumnIndex = cursor.getColumnIndex(HelperDB.COLUMN_HAS_REMINDER);
                if (reminderColumnIndex != -1 && cursor.getInt(reminderColumnIndex) == 1) {
                    createNotification(eventName, eventDate);
                }
            }
            cursor.close();
        } else {
            Toast.makeText(this, "No events found", Toast.LENGTH_SHORT).show();
        }

        calendarAdapter.notifyDataSetChanged();
    }

    private void createNotification(String eventName, String eventDate) {
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Event Reminder")
                .setContentText("Don't forget: " + eventName + " on " + eventDate)
                .setSmallIcon(R.drawable.logo)
                .build();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(0, notification);
        }
    }
}
