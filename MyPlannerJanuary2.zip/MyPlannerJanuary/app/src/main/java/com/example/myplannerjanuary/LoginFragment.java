package com.example.myplannerjanuary;

import android.database.Cursor;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class LoginFragment extends Fragment {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, registerButton;
    private ImageButton eyeButton; // כפתור עין
    private HelperDB helperDB;

    private boolean isPasswordVisible = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("LoginFragment", "onCreateView started");

        // אינפלציה של Layout (הוספת ממשק משתמש)
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // חיבור בין הממשק (XML) לבין המשתנים
        usernameEditText = view.findViewById(R.id.usernameEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        loginButton = view.findViewById(R.id.loginButton);
        registerButton = view.findViewById(R.id.RegisterButton);
        eyeButton = view.findViewById(R.id.eyeButton);

        // יצירת מופע של HelperDB
        helperDB = new HelperDB(getActivity());

        // הוספת מאזין לאירועים של כפתורים
        loginButton.setOnClickListener(v -> handleLogin());
        registerButton.setOnClickListener(v -> goToRegisterFragment());
        eyeButton.setOnClickListener(v -> togglePasswordVisibility());

        return view;
    }

    // פונקציה לביצוע התחברות
    private void handleLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // בדיקת תקינות הקלט
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "נא למלא שם משתמש וסיסמה", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.d("LoginFragment", "Checking user: " + username);

        // חיפוש משתמש במסד הנתונים
        Cursor cursor = helperDB.getUserByUsername(username);

        // אם מצאנו משתמש
        if (cursor != null && cursor.moveToFirst()) {
            String storedPassword = cursor.getString(cursor.getColumnIndex(HelperDB.COLUMN_PASSWORD));

            // בדיקה אם הסיסמה נכונה
            if (storedPassword.equals(password)) {
                Log.d("LoginFragment", "ההתחברות הצליחה");

                // מעבר ל-HomeActivity אחרי התחברות מוצלחת
                Intent intent = new Intent(requireActivity(), HomeActivity.class);
                startActivity(intent);
                requireActivity().finish(); // סגירת האקטיביטי הנוכחית
            } else {
                Log.d("LoginFragment", "סיסמה שגויה");
                Toast.makeText(getActivity(), "סיסמה שגויה", Toast.LENGTH_SHORT).show();
            }
        } else {
            Log.d("LoginFragment", "משתמש לא נמצא");
            Toast.makeText(getActivity(), "משתמש לא נמצא", Toast.LENGTH_SHORT).show();
        }

        // סגירת הקורסור אם הוא נפתח
        if (cursor != null) {
            cursor.close();
        }
    }

    // פונקציה להסתיר/להציג את הסיסמה
    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordEditText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
            isPasswordVisible = false;
        } else {
            passwordEditText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            isPasswordVisible = true;
        }

        // עדכון המיקום של הסמן בסוף השדה
        passwordEditText.setSelection(passwordEditText.getText().length());
    }

    // פונקציה למעבר לפרגמנט רישום
    private void goToRegisterFragment() {
        Log.d("LoginFragment", "Navigating to Register Fragment");
        RegisterFragment registerFragment = new RegisterFragment();
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, registerFragment);  // החלפת פרגמנט
        transaction.addToBackStack(null);  // מאפשר חזרה למסך הקודם
        transaction.commit();  // אישור הפעולה
    }
}


