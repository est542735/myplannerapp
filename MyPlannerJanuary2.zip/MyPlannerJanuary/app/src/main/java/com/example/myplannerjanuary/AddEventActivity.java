package com.example.myplannerjanuary;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class AddEventActivity extends AppCompatActivity {

    public static final String CHANNEL_ID = "event_reminder_channel";
    private static final String CHANNEL_NAME = "Event Reminder Channel";
    private static final String CHANNEL_DESCRIPTION = "Channel for event reminders";

    private TextView dateTextView;
    private TimePicker timePicker;
    private EditText eventNameEditText;
    private Button saveEventButton;
    private Switch reminderSwitch; // Switch כדי להפעיל/לכבות את ההתראה
    private HelperDB dbHelper; // אינסטנס של HelperDB לשמירת אירועים

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dbHelper = new HelperDB(this);

        dateTextView = findViewById(R.id.dateTextView);
        timePicker = findViewById(R.id.timePicker);
        eventNameEditText = findViewById(R.id.eventNameEditText);
        saveEventButton = findViewById(R.id.saveEventButton);
        reminderSwitch = findViewById(R.id.reminderSwitch); // סוויץ' עבור התראה

        // יצירת ערוץ התראות אם הגרסה היא 8 ומעלה
        createNotificationChannel();

        // בקשת הרשאות עבור התראות (בהתאם לגרסה)
        requestNotificationPermission();

        // קבלת הנתונים מה-Intent
        Intent intent = getIntent();
        int year = intent.getIntExtra("year", -1);
        int month = intent.getIntExtra("month", -1);
        int day = intent.getIntExtra("day", -1);

        // הצגת התאריך
        dateTextView.setText("Selected Date: " + day + "/" + (month + 1) + "/" + year);

        // כפתור שמירת האירוע
        saveEventButton.setOnClickListener(v -> {
            String eventName = eventNameEditText.getText().toString();
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            // יצירת מחרוזת זמן בפורמט HH:mm
            String eventTime = String.format("%02d:%02d", hour, minute);

            // שמירה של האירוע בבסיס הנתונים
            boolean hasReminder = reminderSwitch.isChecked();
            String eventDate = year + "-" + (month + 1) + "-" + day;
            saveEventToDatabase(eventName, eventDate, eventTime, hasReminder);

            if (hasReminder) { // אם הסוויץ' עבור התראה פעיל
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED) {
                    setReminder(year, month, day, hour, minute, eventName); // הגדרת התראה
                    Toast.makeText(this, "Event saved with reminder!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Notification permission is required.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Event saved without reminder.", Toast.LENGTH_SHORT).show();
            }

            finish(); // חזרה ל-HomeActivity לאחר שמירת האירוע
        });
    }

    // שמירת אירוע במסד הנתונים
    private void saveEventToDatabase(String eventName, String eventDate, String eventTime, boolean hasReminder) {
        long id = dbHelper.addEvent(eventName, "", eventDate, eventTime, hasReminder);
        if (id != -1) {
            Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save event.", Toast.LENGTH_SHORT).show();
        }
    }

    // יצירת ערוץ התראה
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // יצירת ערוץ עם הגדרה של שם, תיאור וחשיבות
            CharSequence name = CHANNEL_NAME;
            String description = CHANNEL_DESCRIPTION;
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // השגת NotificationManager והוספת הערוץ
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private void setReminder(int year, int month, int day, int hour, int minute, String eventName) {
        try {
            // הגדרת הזמן והתאריך להזכרות
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);

            // יצירת Intent והגדרת PendingIntent
            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("eventName", eventName);
            intent.putExtra("eventTime", String.format("%02d:%02d", hour, minute));

            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            // הגדרת התראה
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) {
                Toast.makeText(this, "Failed to set reminder.", Toast.LENGTH_SHORT).show();
                return;
            }

            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            Toast.makeText(this, "Reminder set successfully!", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Failed to set reminder.", Toast.LENGTH_SHORT).show();
        }
    }

    // בקשת הרשאות עבור התראות (בהתאם לגרסה)
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // אם הגרסה היא אנדרואיד 13 ומעלה, נוודא שההרשאה ניתנה
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }
    }

    // טיפול בתגובה של המשתמש לבקשה הרשאה
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // ההרשאה ניתנה, ניתן לשלוח התראות
                Toast.makeText(this, "Permission granted for notifications.", Toast.LENGTH_SHORT).show();
            } else {
                // ההרשאה לא ניתנה
                Toast.makeText(this, "Permission denied for notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
