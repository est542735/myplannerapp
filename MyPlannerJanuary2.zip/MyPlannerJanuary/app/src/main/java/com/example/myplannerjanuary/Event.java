package com.example.myplannerjanuary;

public class Event {
    private String eventName;
    private String eventDate;
    private String eventTime;

    // Constructor
    public Event(String eventName, String eventDate, String eventTime) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
    }

    // Getters
    public String getEventName() {
        return eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }
}
