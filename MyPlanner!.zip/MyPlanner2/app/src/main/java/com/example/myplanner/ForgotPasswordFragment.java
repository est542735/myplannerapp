package com.example.myplanner;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.content.pm.PackageManager;

public class ForgotPasswordFragment extends Fragment {

    private EditText etUsername, etPhoneNumber, etVerificationCode, etNewPassword;
    private Button btnSendVerificationCode, btnVerifyCode, btnResetPassword;
    private ImageButton btnShowPassword;
    private String verificationCode, phoneNumber, username;
    private boolean isPasswordVisible = false;

    private static final int REQUEST_NOTIFICATION_PERMISSION = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forgot_password, container, false);

        etUsername = view.findViewById(R.id.etUsername);
        etPhoneNumber = view.findViewById(R.id.etPhoneNumber);
        etVerificationCode = view.findViewById(R.id.etVerificationCode);
        etNewPassword = view.findViewById(R.id.etNewPassword);
        btnSendVerificationCode = view.findViewById(R.id.btnSendVerificationCode);
        btnVerifyCode = view.findViewById(R.id.btnVerifyCode);
        btnResetPassword = view.findViewById(R.id.btnResetPassword);
        btnShowPassword = view.findViewById(R.id.btnPasswordVisibility);
        ImageButton btnReturn = view.findViewById(R.id.btnReturn);

        // הסתרת שדות רלוונטיים בהתחלה
        etVerificationCode.setVisibility(View.GONE);
        btnVerifyCode.setVisibility(View.GONE);
        btnResetPassword.setVisibility(View.GONE);
        btnShowPassword.setVisibility(View.GONE);
        etNewPassword.setVisibility(View.GONE);

        btnReturn.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), LoginActivity.class));
            requireActivity().finish();
        });

        btnSendVerificationCode.setOnClickListener(v -> {
            username = etUsername.getText().toString().trim();
            phoneNumber = etPhoneNumber.getText().toString().trim();

            if (username.isEmpty() || phoneNumber.isEmpty()) {
                Toast.makeText(getActivity(), "נא למלא את כל השדות", Toast.LENGTH_SHORT).show();
            } else {
                DBHelper dbHelper = new DBHelper(getActivity());
                boolean userExists = dbHelper.checkUserByUsernameAndPhone(username, phoneNumber);

                if (!userExists) {
                    Toast.makeText(getActivity(), "שם המשתמש או מספר הטלפון שגויים", Toast.LENGTH_SHORT).show();
                } else {
                    verificationCode = generateVerificationCode();
                    showNotificationWithCode(verificationCode);
                    etVerificationCode.setVisibility(View.VISIBLE);
                    btnVerifyCode.setVisibility(View.VISIBLE);
                }
            }
        });

        btnVerifyCode.setOnClickListener(v -> {
            String enteredCode = etVerificationCode.getText().toString().trim();
            if (enteredCode.equals(verificationCode)) {
                etNewPassword.setVisibility(View.VISIBLE);
                btnShowPassword.setVisibility(View.VISIBLE);
                btnResetPassword.setVisibility(View.VISIBLE);
            } else {
                Toast.makeText(getActivity(), "הקוד שהוזן שגוי", Toast.LENGTH_SHORT).show();
            }
        });

        btnResetPassword.setOnClickListener(v -> {
            String newPassword = etNewPassword.getText().toString().trim();
            if (!newPassword.isEmpty()) {
                DBHelper dbHelper = new DBHelper(getActivity());
                boolean isUpdated = dbHelper.updatePasswordByUsernameAndPhone(username, phoneNumber, newPassword);
                if (isUpdated) {
                    Toast.makeText(getActivity(), "הסיסמה שונתה בהצלחה", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                    requireActivity().finish();
                } else {
                    Toast.makeText(getActivity(), "שגיאה באיפוס הסיסמה", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getActivity(), "נא להזין סיסמה חדשה", Toast.LENGTH_SHORT).show();
            }
        });

        btnShowPassword.setOnClickListener(v -> {
            if (isPasswordVisible) {
                etNewPassword.setTransformationMethod(new PasswordTransformationMethod());
                btnShowPassword.setImageResource(R.drawable.eye);
                isPasswordVisible = false;
            } else {
                etNewPassword.setTransformationMethod(null);
                btnShowPassword.setImageResource(R.drawable.eye);
                isPasswordVisible = true;
            }
        });

        return view;
    }

    private String generateVerificationCode() {
        return String.valueOf((int)(Math.random() * 900000) + 100000);
    }

    private void showNotificationWithCode(String code) {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
            return;
        }

        NotificationManager notificationManager =
                (NotificationManager) requireContext().getSystemService(getContext().NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("verify_channel",
                    "Verification Channel", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), "verify_channel")
                .setSmallIcon(R.drawable.logo)
                .setContentTitle("קוד אימות")
                .setContentText("קוד האימות שלך הוא: " + code)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        notificationManager.notify(1, builder.build());
    }
}
