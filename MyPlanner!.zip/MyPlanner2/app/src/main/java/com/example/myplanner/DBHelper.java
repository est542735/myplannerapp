package com.example.myplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyPlanner.db";
    private static final int DATABASE_VERSION = 1;

    // טבלת משתמשים
    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PHONE = "phone";
    public static final String PASSWORD = "password";
    public static final String PROFILE_PIC = "profile_pic";

    // טבלת אירועים
    public static final String TABLE_EVENTS = "events";
    public static final String EVENT_ID = "id";
    public static final String EVENT_NAME = "name";
    public static final String EVENT_DATE = "date";
    public static final String EVENT_TIME = "time";
    public static final String EVENT_CATEGORY = "category";
    public static final String EVENT_DESCRIPTION = "description";
    public static final String EVENT_REMINDER_TIME = "reminder_time";
    public static final String EVENT_STATUS = "status";
    public static final String EVENT_RECURRENCE_PATTERN = "recurrence_pattern";
    public static final String USER_ID_FK = "user_id";

    // טבלת To-Do List
    public static final String TABLE_TODO = "todo";
    public static final String TODO_ID = "id";
    public static final String EVENT_ID_FK = "event_id";
    public static final String IS_COMPLETED = "is_completed";

    // טבלת התראות
    public static final String TABLE_REMINDERS = "reminders";
    public static final String REMINDER_ID = "id";
    public static final String REMINDER_EVENT_ID = "event_id";
    public static final String REMINDER_TIME = "reminder_time";
    public static final String REMINDER_STATUS = "status";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT CHECK(LENGTH(" + USERNAME + ") >= 3), " +
                PHONE + " TEXT UNIQUE CHECK(LENGTH(" + PHONE + ") = 10), " +
                PASSWORD + " TEXT CHECK(LENGTH(" + PASSWORD + ") >= 6), " +
                PROFILE_PIC + " BLOB)";

        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_NAME + " TEXT, " +
                EVENT_DATE + " TEXT, " +
                EVENT_TIME + " TEXT, " +
                EVENT_CATEGORY + " TEXT, " +
                EVENT_DESCRIPTION + " TEXT, " +
                EVENT_REMINDER_TIME + " TEXT, " +
                EVENT_STATUS + " TEXT, " +
                EVENT_RECURRENCE_PATTERN + " TEXT, " +
                USER_ID_FK + " INTEGER, " +
                "FOREIGN KEY(" + USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + USER_ID + "))";

        String createTodoTable = "CREATE TABLE " + TABLE_TODO + " (" +
                TODO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_ID_FK + " INTEGER, " +
                IS_COMPLETED + " INTEGER, " +
                "FOREIGN KEY(" + EVENT_ID_FK + ") REFERENCES " + TABLE_EVENTS + "(" + EVENT_ID + "))";

        String createRemindersTable = "CREATE TABLE " + TABLE_REMINDERS + " (" +
                REMINDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                REMINDER_EVENT_ID + " INTEGER, " +
                REMINDER_TIME + " TEXT, " +
                REMINDER_STATUS + " TEXT, " +
                "FOREIGN KEY(" + REMINDER_EVENT_ID + ") REFERENCES " + TABLE_EVENTS + "(" + EVENT_ID + "))";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
        db.execSQL(createTodoTable);
        db.execSQL(createRemindersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REMINDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TODO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // הוספת משתמש חדש
    public boolean insertUser(String username, String phone, String password, byte[] profilePic) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PHONE, phone);
        values.put(PASSWORD, password);
        values.put(PROFILE_PIC, profilePic);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // הוספת אירוע חדש
    public boolean insertEvent(String name, String date, String time, String category, String description,
                               String reminderTime, String status, String recurrencePattern, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_NAME, name);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);
        values.put(EVENT_CATEGORY, category);
        values.put(EVENT_DESCRIPTION, description);
        values.put(EVENT_REMINDER_TIME, reminderTime);
        values.put(EVENT_STATUS, status);
        values.put(EVENT_RECURRENCE_PATTERN, recurrencePattern);
        values.put(USER_ID_FK, userId);

        long result = db.insert(TABLE_EVENTS, null, values);
        return result != -1;
    }

    // הוספת תזכורת חדשה
    public boolean insertReminder(int eventId, String reminderTime, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(REMINDER_EVENT_ID, eventId);
        values.put(REMINDER_TIME, reminderTime);
        values.put(REMINDER_STATUS, status);

        long result = db.insert(TABLE_REMINDERS, null, values);
        return result != -1;
    }

    // קבלת תמונת פרופיל של משתמש
    public byte[] getProfilePic(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + PROFILE_PIC + " FROM " + TABLE_USERS + " WHERE " + USER_ID + "=?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            byte[] image = cursor.getBlob(0);
            cursor.close();
            return image;
        } else {
            cursor.close();
            return null;
        }
    }

    // עדכון מצב של תזכורת
    public boolean updateReminderStatus(int reminderId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(REMINDER_STATUS, status);

        int result = db.update(TABLE_REMINDERS, values, REMINDER_ID + "=?", new String[]{String.valueOf(reminderId)});
        return result > 0;
    }

    // קבלת תזכורות עתידיות
    public Cursor getFutureReminders() {
        SQLiteDatabase db = this.getReadableDatabase();
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String query = "SELECT * FROM " + TABLE_REMINDERS + " r " +
                "JOIN " + TABLE_EVENTS + " e ON r." + REMINDER_EVENT_ID + " = e." + EVENT_ID +
                " WHERE e." + EVENT_DATE + " >= ?";

        return db.rawQuery(query, new String[]{currentDate});
    }

    // אימות התחברות של משתמש
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + USERNAME + " = ? AND " + PASSWORD + " = ?", new String[]{username, password});
        if (cursor != null && cursor.moveToFirst()) {
            cursor.close();
            return true;
        } else {
            cursor.close();
            return false;
        }
    }

    // פונקציה לבדוק אם טלפון קיים כבר
    public boolean isPhoneExists(String phone) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + PHONE + " = ?", new String[]{phone});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // עדכון סיסמה לפי שם משתמש ומספר טלפון
    public boolean updatePasswordByUsernameAndPhone(String username, String phone, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PASSWORD, newPassword);

        int result = db.update(TABLE_USERS, values, USERNAME + "=? AND " + PHONE + "=?", new String[]{username, phone});
        return result > 0;
    }

}
