package com.example.myplanner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin, btnRegister, btnForgotPassword;
    private ImageButton btnTogglePasswordVisibility;
    private boolean isPasswordVisible = false;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnForgotPassword = findViewById(R.id.btnForgotPassword);
        btnTogglePasswordVisibility = findViewById(R.id.btnPasswordVisibility);

        dbHelper = new DBHelper(this);

        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "נא להזין שם משתמש וסיסמה", Toast.LENGTH_SHORT).show();
            } else {
                if (dbHelper.validateLogin(username, password)) {
                    SharedPreferences prefs = getSharedPreferences("MyApp", MODE_PRIVATE);
                    prefs.edit().putString("username", username).apply();

                    Toast.makeText(this, "התחברות הצליחה", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, HomeActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "שם משתמש או סיסמה לא נכונים", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRegister.setOnClickListener(v ->
                getSupportFragmentManager().beginTransaction()
                        .replace(android.R.id.content, new RegisterFragment())
                        .addToBackStack(null)
                        .commit()
        );

        btnForgotPassword.setOnClickListener(v ->
                getSupportFragmentManager().beginTransaction()
                        .replace(android.R.id.content, new ForgotPasswordFragment())
                        .addToBackStack(null)
                        .commit()
        );

        btnTogglePasswordVisibility.setOnClickListener(v -> {
            if (isPasswordVisible) {
                etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            } else {
                etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            }
            etPassword.setSelection(etPassword.length());
            isPasswordVisible = !isPasswordVisible;
        });
    }
}
