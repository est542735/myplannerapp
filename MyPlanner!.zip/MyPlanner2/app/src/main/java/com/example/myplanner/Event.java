package com.example.myplanner;

public class Event {
    private int eventId;
    private String eventName;
    private String eventDate;
    private String eventTime;
    private String eventCategory;
    private String eventDescription;
    private String eventReminderTime;
    private String eventStatus;
    private String eventRecurrencePattern;
    private int userId;

    public Event(int eventId, String eventName, String eventDate, String eventTime, String eventCategory,
                 String eventDescription, String eventReminderTime, String eventStatus,
                 String eventRecurrencePattern, int userId) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.eventCategory = eventCategory;
        this.eventDescription = eventDescription;
        this.eventReminderTime = eventReminderTime;
        this.eventStatus = eventStatus;
        this.eventRecurrencePattern = eventRecurrencePattern;
        this.userId = userId;
    }

    // Getter methods
    public int getEventId() {
        return eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public String getEventCategory() {
        return eventCategory;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public String getEventReminderTime() {
        return eventReminderTime;
    }

    public String getEventStatus() {
        return eventStatus;
    }

    public String getEventRecurrencePattern() {
        return eventRecurrencePattern;
    }

    public int getUserId() {
        return userId;
    }
}
