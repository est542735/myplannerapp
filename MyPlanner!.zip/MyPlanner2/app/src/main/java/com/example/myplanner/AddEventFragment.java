package com.example.myplanner;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddEventFragment extends Fragment {

    private EditText etEventName, etEventDescription;
    private TextView tvEventDate, tvEventTime;
    private Button btnSaveEvent;
    private ImageButton btnReturn;

    private DBHelper dbHelper;
    private Calendar calendar;

    public AddEventFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_add_event, container, false);

        // התחברות לרכיבים
        etEventName = rootView.findViewById(R.id.etEventName);
        etEventDescription = rootView.findViewById(R.id.etEventDescription);
        tvEventDate = rootView.findViewById(R.id.tvEventDate);
        tvEventTime = rootView.findViewById(R.id.tvEventTime);
        btnSaveEvent = rootView.findViewById(R.id.btnSaveEvent);
        btnReturn = rootView.findViewById(R.id.btnReturn);

        // יצירת אובייקט DBHelper
        dbHelper = new DBHelper(getContext());
        calendar = Calendar.getInstance();

        // הגדרת פעולה לכפתור חזרה
        btnReturn.setOnClickListener(v -> {
            // יצירת Intent לפתיחה של HomeActivity
            Intent intent = new Intent(getContext(), HomeActivity.class);
            // סיום הפעולה הנוכחית
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            // סיום ה-Fragment הנוכחי
            requireActivity().finish();
        });

        // לחיצה על תאריך
        tvEventDate.setOnClickListener(v -> showDatePicker());

        // לחיצה על שעה
        tvEventTime.setOnClickListener(v -> showTimePicker());

        // לחיצה על כפתור שמירה
        btnSaveEvent.setOnClickListener(v -> saveEvent());

        return rootView;
    }

    private void showDatePicker() {
        // יצירת תאריך לבחירה
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    // הגדרת התאריך שנבחר
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, monthOfYear);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    // עדכון ה-TextView עם התאריך הנבחר
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
                    tvEventDate.setText(sdf.format(calendar.getTime()));
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.show();
    }

    private void showTimePicker() {
        // יצירת שעה לבחירה
        TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(),
                (view, hourOfDay, minute) -> {
                    // הגדרת השעה שנבחרה
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);

                    // עדכון ה-TextView עם השעה הנבחרת
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.US);
                    tvEventTime.setText(sdf.format(calendar.getTime()));
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true);

        timePickerDialog.show();
    }

    private void saveEvent() {
        // קבלת הערכים מהשדות
        String eventName = etEventName.getText().toString();
        String eventDescription = etEventDescription.getText().toString();

        // לדוגמה, תאריך ושעה נבחרים באופן ידני
        String eventDate = tvEventDate.getText().toString();
        String eventTime = tvEventTime.getText().toString();

        // שמירת האירוע למסד הנתונים
        boolean isInserted = dbHelper.insertEvent(eventName, eventDate, eventTime, "", eventDescription,
                "", "Active", "", 1); // הערך '1' הוא לדוגמה, תלוי במשתמש המחובר

        if (isInserted) {
            // אם האירוע נוסף בהצלחה, להראות הודעת הצלחה
            Toast.makeText(getContext(), "האירוע נשמר בהצלחה!", Toast.LENGTH_SHORT).show();

            // יצירת Intent לפתיחה של HomeActivity
            Intent intent = new Intent(getContext(), HomeActivity.class);
            // סיום הפעולה הנוכחית
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

            // סיום ה-Fragment הנוכחי
            requireActivity().finish();
        } else {
            // הצגת הודעת שגיאה אם האירוע לא נשמר
            Toast.makeText(getContext(), "אירעה שגיאה בשמירת האירוע. נסה שנית.", Toast.LENGTH_SHORT).show();
        }
    }
}
