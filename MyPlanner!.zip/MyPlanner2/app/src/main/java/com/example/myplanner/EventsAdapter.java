package com.example.myplanner;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.EventViewHolder> {

    private List<Event> eventList;

    // קונסטרוקטור שמקבל את רשימת האירועים
    public EventsAdapter(List<Event> eventList) {
        this.eventList = eventList;
    }

    // יצירת ViewHolder עבור כל פריט ברשימה
    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    // הצגת הנתונים של כל פריט
    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.eventName.setText(event.getEventName());
        holder.eventTime.setText(event.getEventTime());
        holder.eventDate.setText(event.getEventDate());
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // ViewHolder אשר אחראי לפריט ב-RecyclerView
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventName, eventTime, eventDate;

        public EventViewHolder(View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.eventName);
            eventTime = itemView.findViewById(R.id.eventTime);
            eventDate = itemView.findViewById(R.id.eventDate);
        }
    }
}
