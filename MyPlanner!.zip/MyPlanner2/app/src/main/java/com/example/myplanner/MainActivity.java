package com.example.myplanner;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // משתנה לייצוג הלוגו
    private ImageView logoImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // קישור בין משתנה הלוגו ל-XML
        logoImageView = findViewById(R.id.LogoImageView);

        // הפעלת אנימציה ללוגו
        startLogoAnimation();

        // הפעלת טיימר של 3 שניות למעבר למסך ההתחברות
        startCountDownTimer();
    }

    /*** מפעילה אנימציה של סיבוב ללוגו */
    private void startLogoAnimation() {
        logoImageView.setAlpha(0f); // מתחילים עם שקיפות מלאה
        logoImageView.setTranslationX(1000f); // הלוגו מתחיל מחוץ למסך מימין

        // הפעלת האנימציה
        logoImageView.animate()
                .translationX(0f) // הלוגו יזוז למרכז (אפס מיקום ב-X)
                .rotation(360f) // סיבוב מלא של הלוגו
                .alpha(1f) // הלוגו יפך להיות גלוי (שקיפות מלאה)
                .setDuration(2000); // משך האנימציה ב-2 שניות
    }

    /*** מפעילה טיימר נספר לאחור של 3 שניות */
    private void startCountDownTimer() {
        new CountDownTimer(3000, 1000) { // טיימר של 3000 מילישניות (3 שניות) עם צעדים של 1000 מילישניות
            @Override
            public void onTick(long millisUntilFinished) {
                // כל שנייה שעוברת
                // ניתן להוסיף כאן עדכון UI אם רוצים להציג את הזמן שנותר
            }

            @Override
            public void onFinish() {
                // סיום הטיימר – המעבר למסך הבא
                Intent intent = new Intent(MainActivity.this, LoginActivity.class); // מעבר למסך LoginActivity
                startActivity(intent); // הפעלת הפעילות
                finish(); // סיום MainActivity כדי למנוע חזרה
            }
        }.start(); // התחלת הטיימר
    }
}
