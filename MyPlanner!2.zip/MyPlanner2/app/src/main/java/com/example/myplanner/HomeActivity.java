package com.example.myplanner;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // ודא שזה השם הנכון של הקובץ שלך

        // התחברות לרכיבים
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        Toolbar toolbar = findViewById(R.id.toolbar);
        AppCompatImageButton menuButton = findViewById(R.id.menuButton);

        setSupportActionBar(toolbar);

        // פתיחה/סגירה של המגירה בלחיצה על כפתור ההמבורגר
        menuButton.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START);
            } else {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // טיפול בלחיצות בתפריט הצד
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                Fragment selectedFragment = null;

                if (itemId == R.id.item_settings) {
                    // הצג את פרגמנט ההגדרות
                    selectedFragment = new SettingsFragment();
                } else if (itemId == R.id.item_to_do_list) {
                    // הצג את פרגמנט רשימת המשימות
                    selectedFragment = new ToDoListFragment();
                }

                if (selectedFragment != null) {
                    // המרת פרגמנט לתוך ה-FrameLayout
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragmentContainer, selectedFragment); // מסך המארח את הפרגמנטים
                    transaction.addToBackStack(null); // אם רוצים שיכללו בהיסטוריית החזרה
                    transaction.commit();
                }

                drawerLayout.closeDrawer(GravityCompat.START); // סגור את המגירה
                return true;
            }
        });
    }
}
