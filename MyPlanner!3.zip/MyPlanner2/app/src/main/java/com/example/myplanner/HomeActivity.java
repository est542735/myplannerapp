package com.example.myplanner;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private FloatingActionButton fabAddEvent; // כפתור פלוס

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // התחברות לרכיבים
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        Toolbar toolbar = findViewById(R.id.toolbar);
        AppCompatImageButton menuButton = findViewById(R.id.menuButton);
        fabAddEvent = findViewById(R.id.fabAddEvent); // התחברות ל-FAB

        setSupportActionBar(toolbar);

        // להסתיר כותרת מה-Toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // פתיחת/סגירת מגירה בלחיצה על ההמבורגר
        menuButton.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START);
            } else {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // לחיצה על כפתור הפלוס - מעבר ל-AddEventFragment
        fabAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFullScreenFragment(new AddEventFragment());
            }
        });

        // טיפול בלחיצות על פריטי המגירה
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                Fragment selectedFragment = null;

                if (itemId == R.id.item_settings) {
                    selectedFragment = new SettingsFragment();
                } else if (itemId == R.id.item_to_do_list) {
                    selectedFragment = new ToDoListFragment();
                }

                if (selectedFragment != null) {
                    openFragment(selectedFragment);
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    // פונקציה לפתיחת פרגמנט כעל מסך מלא
    private void openFullScreenFragment(Fragment fragment) {
        // הסתרת כל התצוגות בממשק
        findViewById(R.id.toolbar).setVisibility(View.GONE);
        findViewById(R.id.fabAddEvent).setVisibility(View.GONE);
        findViewById(R.id.calendarView).setVisibility(View.GONE);
        findViewById(R.id.tvSelectedDate).setVisibility(View.GONE);
        findViewById(R.id.rvEvents).setVisibility(View.GONE);
        findViewById(R.id.navigationView).setVisibility(View.GONE);

        // פתיחת ה-Fragment על כל המסך
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(android.R.id.content, fragment); // מחליף את כל התצוגה הנוכחית עם ה-Fragment
        transaction.addToBackStack(null); // מאפשר חזרה אחורה
        transaction.commit();
    }

    // פונקציה לפתיחת פרגמנט רגיל (לא על כל המסך)
    private void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
