package com.example.myplannerjanuary;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // קבלת שם ושעת האירוע
        String eventName = intent.getStringExtra("eventName");
        String eventTime = intent.getStringExtra("eventTime");

        // יצירת Intent להתראה
        Intent notificationIntent = new Intent(context, HomeActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // בניית התראה
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, AddEventActivity.CHANNEL_ID)
                .setSmallIcon(R.drawable.logo) // החלף באייקון מתאים
                .setContentTitle("Reminder: " + eventName)
                .setContentText("Your event is scheduled at " + eventTime + ".")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        // הצגת ההתראה
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify((int) System.currentTimeMillis(), notificationBuilder.build());
        }
    }
}

