package com.example.myplannerjanuary;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.EventViewHolder> {

    private List<Event> eventList;

    public CalendarAdapter(List<Event> eventList) {
        this.eventList = eventList;
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.eventName.setText(event.getEventName());
        holder.eventDescription.setText(event.getEventDescription());
        holder.eventDate.setText(event.getEventDate());
        holder.eventTime.setText(event.getEventTime());
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        public TextView eventName, eventDescription, eventDate, eventTime;

        public EventViewHolder(View view) {
            super(view);
            eventName = view.findViewById(R.id.eventName);
            eventDescription = view.findViewById(R.id.eventDescription);
            eventDate = view.findViewById(R.id.eventDate);
            eventTime = view.findViewById(R.id.eventTime);
        }
    }
}
