package com.example.myplannerjanuary;

public class Event {
    private String eventName;
    private String eventDescription;
    private String eventDate;
    private String eventTime;
    private boolean hasReminder;

    // קונסטרוקטור עם 5 פרמטרים (כולל תיאור, תאריך, שעה והתראה)
    public Event(String eventName, String eventDescription, String eventDate, String eventTime, boolean hasReminder) {
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.hasReminder = hasReminder;
    }

    // קונסטרוקטור עם 4 פרמטרים (ללא תיאור - ברירת מחדל תיאור ריק)
    public Event(String eventName, String eventDate, String eventTime, boolean hasReminder) {
        this.eventName = eventName;
        this.eventDescription = ""; // תיאור ריק ברירת מחדל
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.hasReminder = hasReminder;
    }

    // קונסטרוקטור עם 3 פרמטרים (ללא תיאור וללא התראה - ברירת מחדל)
    public Event(String eventName, String eventDate, String eventTime) {
        this.eventName = eventName;
        this.eventDescription = ""; // תיאור ריק ברירת מחדל
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.hasReminder = false; // אין התראה ברירת מחדל
    }

    // גטרים וסטטרים (אם דרושים)
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public boolean isHasReminder() {
        return hasReminder;
    }

    public void setHasReminder(boolean hasReminder) {
        this.hasReminder = hasReminder;
    }
}
